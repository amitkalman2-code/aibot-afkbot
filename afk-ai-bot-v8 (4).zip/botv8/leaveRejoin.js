const { addLog } = require('./logger')
function randomMs(min,max){ return Math.floor(Math.random()*(max-min+1))+min }

function setupLeaveRejoin(bot, onDisconnect, getSettings) {
  let leaveTimer=null, jumpTimer=null, jumpOffTimer=null, stopped=false
  let stuckCheckTimer=null, lastPos=null, lastPosTime=0

  function cleanup(){
    stopped=true
    clearTimeout(leaveTimer); clearTimeout(jumpTimer); clearTimeout(jumpOffTimer)
    clearInterval(stuckCheckTimer)
    leaveTimer=jumpTimer=jumpOffTimer=stuckCheckTimer=null
  }

  function scheduleJump(){
    if(stopped||!bot.entity) return
    const cfg=getSettings()
    if(!cfg.bot.antiAfk) return
    try { bot.setControlState('jump',true) } catch(_) {}
    jumpOffTimer=setTimeout(()=>{ try{bot.setControlState('jump',false)}catch(_){} },300)
    jumpTimer=setTimeout(scheduleJump, randomMs((cfg.bot.jumpInterval||60)*1000, (cfg.bot.jumpInterval||60)*1500))
  }

  // ── Auto-jump when stuck while walking ──────────────────────────────────────
  function startStuckCheck(){
    stuckCheckTimer=setInterval(()=>{
      if(stopped||!bot||!bot.entity) return
      const cfg=getSettings()
      if(!cfg.bot.autoJumpWalk) return
      let isMoving=false
      try{ isMoving=!!(bot.pathfinder&&bot.pathfinder.isMoving&&bot.pathfinder.isMoving()) }catch(_){}
      if(!isMoving) return
      const pos=bot.entity.position
      const now=Date.now()
      if(lastPos){
        const dx=pos.x-lastPos.x, dz=pos.z-lastPos.z
        const movedH=Math.sqrt(dx*dx+dz*dz)
        if(now-lastPosTime>1500 && movedH<0.3){
          try{
            bot.setControlState('jump',true)
            setTimeout(()=>{try{bot.setControlState('jump',false)}catch(_){}},400)
            addLog('[Movement] Auto-jumped (stuck)')
          }catch(_){}
          lastPos=null; lastPosTime=now; return
        }
      }
      if(!lastPos||movedEnough(pos,lastPos)){
        lastPos={x:pos.x,y:pos.y,z:pos.z}
        lastPosTime=now
      }
    },500)
  }
  function movedEnough(a,b){if(!b)return true;const dx=a.x-b.x,dz=a.z-b.z;return Math.sqrt(dx*dx+dz*dz)>0.3}

  bot.once('spawn',()=>{
    cleanup(); stopped=false; lastPos=null
    const cfg=getSettings()

    // Restore persisted task
    if(cfg.bot.persistedTask){
      addLog(`[Task] Restoring persisted task: "${cfg.bot.persistedTask}"`)
      setTimeout(()=>{
        try{
          const{doAction}=require('./ai')
          doAction(bot,cfg.bot.persistedTask,cfg.ai,!!(cfg.ai.keys?.[cfg.ai.provider]||'')).catch(()=>{})
        }catch(_){}
      },3000)
    }

    startStuckCheck()

    // neverLeave=true OR enableLeaveRejoin=false → stay forever
    const leaveRejoinOn = cfg.bot.enableLeaveRejoin && !cfg.bot.neverLeave
    if(!leaveRejoinOn){
      addLog(`[AFK] Leave/Rejoin OFF — bot stays forever (disable in Bot Settings to allow cycling)`)
      scheduleJump()
      return
    }

    const stay=randomMs((cfg.bot.stayMin||60)*1000,(cfg.bot.stayMax||300)*1000)
    addLog(`[AFK] Leave/Rejoin ON — cycling in ${Math.round(stay/1000)}s (Bot Settings → Disable to stop)`)
    scheduleJump()
    leaveTimer=setTimeout(()=>{
      if(stopped) return
      cleanup()
      try{ bot.quit() }catch(_){}
    },stay)
  })

  bot.on('end',()=>{ cleanup(); onDisconnect() })
  bot.on('kicked',cleanup)
  bot.on('error',cleanup)
}

module.exports = setupLeaveRejoin
