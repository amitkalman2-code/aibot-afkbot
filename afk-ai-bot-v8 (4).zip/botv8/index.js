const mineflayer = require('mineflayer')
const { pathfinder, goals, Movements } = require('mineflayer-pathfinder')
const express = require('express')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { addLog, getLogs } = require('./logger')
const { askAI, doAction, setCustomCmds, stopAllRepeat } = require('./ai')
const { loadSettings, saveSettings } = require('./settings')
const setupLeaveRejoin = require('./leaveRejoin')

const app = express()
app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')))

const modsDir = path.join(__dirname, 'mods')
if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir)
const upload = multer({ dest: modsDir })

let bot = null
let botOnline = false
let reconnectTimer = null
let randomLookTimer = null
let guardTimer = null
let collectTimer = null

function hasAPI() {
  const cfg = loadSettings()
  return !!(cfg.ai.keys?.[cfg.ai.provider] || '')
}

// ── API routes ─────────────────────────────────────────────────────────────────
app.get('/api/settings', (req, res) => res.json(loadSettings()))
app.post('/api/settings', (req, res) => {
  saveSettings(req.body)
  if (req.body.customCmds) setCustomCmds(req.body.customCmds)
  addLog('[Settings] Saved.')
  applyBotSettings()
  res.json({ ok: true })
})
app.get('/api/status', (req, res) => res.json({ online: botOnline, logs: getLogs(), hasAPI: hasAPI() }))
app.post('/api/restart', (req, res) => {
  addLog('[Bot] Restart requested.')
  if (bot) { try { bot.quit() } catch(_) {} }
  clearTimeout(reconnectTimer)
  reconnectTimer = setTimeout(createBot, 2000)
  res.json({ ok: true })
})
app.post('/api/chat', (req, res) => {
  const { msg } = req.body
  if (!bot || !botOnline) return res.json({ ok: false, error: 'Bot offline' })
  try { bot.chat(String(msg)); addLog(`[Dashboard] Sent: ${msg}`); res.json({ ok: true }) }
  catch(e) { res.json({ ok: false, error: e.message }) }
})

// Save/clear persisted task
app.post('/api/task/persist', (req, res) => {
  const { task } = req.body
  saveSettings({ bot: { persistedTask: task || '' } })
  addLog(task ? `[Task] Persisted: ${task}` : '[Task] Cleared persisted task')
  res.json({ ok: true })
})
app.get('/api/task/persist', (req, res) => {
  res.json({ task: loadSettings().bot.persistedTask || '' })
})

app.post('/api/voice', async (req, res) => {
  const { text } = req.body
  if (!text) return res.json({ ok: false, error: 'No text' })
  if (!bot || !botOnline) return res.json({ ok: false, error: 'Bot offline' })
  addLog(`[Voice] Heard: "${text}"`)
  const cfg = loadSettings()
  const api = hasAPI()
  let result = ''
  try {
    if (!api) {
      // No API key — just try as direct command
      result = await doAction(bot, text, cfg.ai, false)
    } else {
      // Use AI to understand natural speech → pick best command
      const voicePrompt = `You control a Minecraft bot. The player said via voice: "${text}"
Your job: decide if they want the bot to DO something or ANSWER a question.

If they want the bot to DO something, reply ONLY with:
DO: <exact command>

If they want an ANSWER/info, reply ONLY with:
ASK: <question to answer>

Available bot commands (use exact syntax):
jump | sneak | unsneak | sprint | stop | leave | spin | dance | wave | roar | sit | stand | charge | patrol | strafe | circle | toss junk | look around | facing | version | hunger | speed | nearby | hello | walk X Y Z | walk forward [N] | walk back [N] | walk left [N] | walk right [N] | mine <block> | find <block> | kill <mob> | follow <player> | come | say <message> | look north/south/east/west/up/down | look at <player> | inv | inv all | hotbar | health | pos | time | eat | fly | day | night | creative | survival | tp <player> | slot <1-9> | nearest | jump <N> | sprint on | sprint off | sneak on | sneak off | stop moving | block under | block look | count <item> | player count | tps | light level | dimension | give <player> <item> | kick <player> | ban <player>

Examples:
"jump three times" → DO: jump 3
"walk to 100 64 200" → DO: walk 100 64 200
"go forward 20 blocks" → DO: walk forward 20
"follow Steve" → DO: follow Steve
"what's my health" → ASK: health status
"say hello everyone" → DO: say hello everyone
"stop everything" → DO: stop
"how many players are online" → DO: player count
"mine some stone" → DO: mine stone`

      const aiReply = (await askAI(voicePrompt, cfg.ai)).trim()
      addLog(`[Voice] AI decision: ${aiReply.slice(0,80)}`)

      if (aiReply.toUpperCase().startsWith('DO:')) {
        const cmd = aiReply.slice(3).trim()
        result = await doAction(bot, cmd, cfg.ai, api)
      } else if (aiReply.toUpperCase().startsWith('ASK:')) {
        const q = aiReply.slice(4).trim()
        result = await doAction(bot, q, cfg.ai, api)
        if (!result || result.startsWith('Unknown')) {
          result = await askAI(q, cfg.ai)
          bot.chat(result.slice(0,255))
        }
      } else {
        // AI returned something weird — treat raw as command
        result = await doAction(bot, aiReply, cfg.ai, api)
      }
    }
    addLog(`[Voice] Result: ${result.slice(0,80)}`)
    res.json({ ok: true, result })
  } catch(e) {
    addLog(`[Voice Error] ${e.message}`)
    res.json({ ok: false, error: e.message })
  }
})

app.get('/api/customcmds', (req, res) => res.json(loadSettings().customCmds || {}))
app.post('/api/customcmds', (req, res) => {
  saveSettings({ customCmds: req.body })
  setCustomCmds(req.body)
  addLog('[CustomCmds] Saved.')
  res.json({ ok: true })
})

app.post('/api/mods/upload', upload.single('mod'), (req, res) => {
  if (!req.file) return res.json({ ok: false, error: 'No file' })
  const orig = req.file.originalname
  const dest = path.join(modsDir, orig)
  fs.renameSync(req.file.path, dest)
  const cfg = loadSettings()
  const mods = cfg.mods||[]
  if (!mods.find(m=>m.name===orig)) mods.push({ name:orig, note:'Uploaded', file:dest })
  saveSettings({ mods })
  addLog(`[Mods] Uploaded: ${orig}`)
  res.json({ ok: true, name: orig })
})
app.get('/api/mods', (req, res) => res.json(loadSettings().mods||[]))
app.delete('/api/mods/:name', (req, res) => {
  const name = decodeURIComponent(req.params.name)
  const cfg = loadSettings()
  saveSettings({ mods: (cfg.mods||[]).filter(m=>m.name!==name) })
  try { const f=path.join(modsDir,name); if(fs.existsSync(f)) fs.unlinkSync(f) } catch(_) {}
  addLog(`[Mods] Removed: ${name}`)
  res.json({ ok: true })
})

// ── Apply bot settings live ────────────────────────────────────────────────────
function applyBotSettings() {
  if (!bot || !botOnline) return
  const cfg = loadSettings()
  const b = cfg.bot

  clearInterval(randomLookTimer)
  if (b.randomLook) {
    randomLookTimer = setInterval(() => {
      if (!bot||!botOnline) return
      try { bot.look(Math.random()*Math.PI*2,(Math.random()-.5)*Math.PI,false) } catch(_) {}
    }, (b.randomLookInterval||120)*1000)
  }

  clearInterval(guardTimer)
  if (b.guardMode) {
    const hostile=['zombie','skeleton','creeper','spider','witch','enderman','phantom','slime','blaze','ghast','pillager','ravager','vindicator','evoker']
    guardTimer = setInterval(() => {
      if (!bot||!botOnline) return
      const entity = Object.values(bot.entities).find(e=>{
        if(!e||e===bot.entity) return false
        return bot.entity.position.distanceTo(e.position)<=(b.guardRange||5) && hostile.includes((e.name||'').toLowerCase())
      })
      if (entity) { try{bot.pathfinder.setGoal(new goals.GoalFollow(entity,2),true);bot.attack(entity)}catch(_){} }
    }, 1000)
  }

  clearInterval(collectTimer)
  if (b.collectDrops) {
    collectTimer = setInterval(() => {
      if (!bot||!botOnline) return
      const drop = Object.values(bot.entities).find(e=>e.name==='item'&&bot.entity.position.distanceTo(e.position)<=8)
      if (drop) { try{bot.pathfinder.setGoal(new goals.GoalBlock(Math.round(drop.position.x),Math.round(drop.position.y),Math.round(drop.position.z)))}catch(_){} }
    }, 2000)
  }

  if (b.lookAtPlayers) {
    const nearest = Object.values(bot.entities).find(e=>e.type==='player'&&e!==bot.entity)
    if (nearest) try{bot.lookAt(nearest.position.offset(0,1.6,0))}catch(_){}
  }

  if (b.followPlayer) {
    const entity = Object.values(bot.entities).find(e=>e.type==='player'&&(e.username||'').toLowerCase()===b.followPlayer.toLowerCase())
    if (entity) try{bot.pathfinder.setGoal(new goals.GoalFollow(entity,b.followRange||3),true)}catch(_){}
  }
}

// ── Realistic knockback ────────────────────────────────────────────────────────
function setupRealisticKB(bot) {
  // Hook raw entity_velocity packet — mineflayer normally ignores it for the self entity
  // This makes the bot actually get pushed back when hit, just like a real player
  bot._client.on('entity_velocity', (packet) => {
    try {
      if (!bot.entity) return
      const cfg = loadSettings()
      if (!cfg.bot.realisticKB) return
      if (packet.entityId !== bot.entity.id) return
      // velocities are in units/8000 per the MC protocol
      const vx = packet.velocityX / 8000
      const vy = packet.velocityY / 8000
      const vz = packet.velocityZ / 8000
      // Apply to the physics entity directly
      bot.entity.velocity.x = vx
      bot.entity.velocity.y = vy
      bot.entity.velocity.z = vz
      // Also stop pathfinder so the KB actually takes effect
      try { bot.pathfinder.stop() } catch(_) {}
      addLog(`[KB] Knockback applied: ${vx.toFixed(2)} ${vy.toFixed(2)} ${vz.toFixed(2)}`)
    } catch(_) {}
  })
}

// ── Create bot ─────────────────────────────────────────────────────────────────
function createBot() {
  const cfg = loadSettings()
  if (!cfg.server.host) { addLog('[Error] No server host. Configure in Server tab.'); return }
  addLog(`[Bot] Connecting to ${cfg.server.host}:${cfg.server.port} as "${cfg.server.username}"...`)
  setCustomCmds(cfg.customCmds||{})

  try {
    bot = mineflayer.createBot({
      host: cfg.server.host,
      port: cfg.server.port||25565,
      username: cfg.server.username||'AFKBot',
      version: cfg.server.version||'1.21.11',
      auth: 'offline',
      hideErrors: false,
      // Let server send velocity packets (needed for real KB)
      physicsEnabled: true,
    })
  } catch(e) { addLog(`[Bot] Failed: ${e.message}`); return }

  bot.loadPlugin(pathfinder)

  // Setup realistic KB as soon as bot client is ready
  setupRealisticKB(bot)

  setupLeaveRejoin(bot, () => {
    const c = loadSettings()
    if (c.bot.autoReconnect!==false) { clearTimeout(reconnectTimer); reconnectTimer=setTimeout(createBot,c.bot.reconnectDelay||5000) }
  }, loadSettings)

  bot.once('spawn', () => {
    botOnline = true
    addLog(`[Bot] ✅ Joined ${cfg.server.host}`)
    const c = loadSettings()
    try { const mv=new Movements(bot); bot.pathfinder.setMovements(mv) } catch(_) {}
    if (c.bot.welcomeMsg && c.bot.welcomeText) setTimeout(()=>{ try{bot.chat(c.bot.welcomeText)}catch(_){} },1500)
    if (c.bot.coordsOnSpawn) { const p=bot.entity.position; setTimeout(()=>{ try{bot.chat(`Spawned at X:${Math.round(p.x)} Y:${Math.round(p.y)} Z:${Math.round(p.z)}`)}catch(_){} },2000) }
    applyBotSettings()
  })

  bot.on('playerJoined', (player) => {
    if (player.username===bot.username) return
    const c = loadSettings()
    addLog(`[Join] ${player.username} joined`)
    if (c.bot.playerJoinMsg && c.bot.playerJoinText) {
      const msg = c.bot.playerJoinText.replace('{player}',player.username)
      setTimeout(()=>{ try{bot.chat(msg)}catch(_){} },1000)
    }
  })
  bot.on('playerLeft', (player) => {
    if (player.username===bot.username) return
    const c = loadSettings()
    addLog(`[Leave] ${player.username} left`)
    if (c.bot.playerLeaveMsg && c.bot.playerLeaveText) {
      const msg = c.bot.playerLeaveText.replace('{player}',player.username)
      setTimeout(()=>{ try{bot.chat(msg)}catch(_){} },500)
    }
  })

  bot.on('chat', async (username, message) => {
    if (username===bot.username) return
    const c = loadSettings()
    if (c.bot.chatLog!==false && !c.bot.muteChat) addLog(`[Chat] <${username}> ${message}`)
    if (!c.bot.chatResponse||c.bot.muteChat) return

    const askPfx = (c.ai.chatPrefix||'ask').toLowerCase()
    const doPfx  = (c.ai.doPrefix||'do').toLowerCase()
    const msgL = message.toLowerCase()
    const api = hasAPI()

    if (msgL.includes('whispers')||msgL.startsWith('[pm]')||msgL.startsWith('(pm)')) {
      const content = message.replace(/.*?:\s*/,'').trim()
      if (content.toLowerCase().startsWith(doPfx+' ')) {
        const cmd = content.slice(doPfx.length+1).trim()
        try { const r=await doAction(bot,cmd,c.ai,api); bot.chat(`/msg ${username} ${r.slice(0,200)}`) } catch(_) {}
      } else if (content.toLowerCase().startsWith(askPfx+' ')) {
        const q = content.slice(askPfx.length+1).trim()
        try { const r=await askAI(q,c.ai); bot.chat(`/msg ${username} ${r.slice(0,200)}`) } catch(_) {}
      }
      return
    }

    if (msgL.startsWith(askPfx+' ')) {
      const q = message.slice(askPfx.length+1).trim()
      if (!api) { bot.chat('No AI API key set. Configure in AI Settings.'); return }
      addLog(`[AI] ask from ${username}: ${q}`)
      try { const reply=await askAI(q,c.ai); bot.chat(reply.slice(0,255)); addLog(`[AI] ${reply.slice(0,80)}`) }
      catch(e) { bot.chat('AI error: '+e.message.slice(0,80)); addLog(`[AI Error] ${e.message}`) }
      return
    }

    if (msgL.startsWith(doPfx+' ')) {
      const cmd = message.slice(doPfx.length+1).trim()
      addLog(`[Do] ${username}: ${cmd}`)
      try { const r=await doAction(bot,cmd,c.ai,api); bot.chat(r.slice(0,255)); addLog(`[Do] ${r.slice(0,80)}`) }
      catch(e) { bot.chat('Error: '+e.message.slice(0,80)); addLog(`[Do Error] ${e.message}`) }
      return
    }

    if (c.ai.respondToAll && api) {
      try { const r=await askAI(message,c.ai); bot.chat(r.slice(0,255)) } catch(_) {}
    }
  })

  bot.on('end', (reason) => {
    botOnline=false
    clearInterval(randomLookTimer); clearInterval(guardTimer); clearInterval(collectTimer)
    addLog(`[Bot] Disconnected: ${reason}`)
    const c=loadSettings()
    if (c.bot.autoReconnect!==false) { clearTimeout(reconnectTimer); reconnectTimer=setTimeout(createBot,c.bot.reconnectDelay||5000) }
  })
  bot.on('kicked', (r) => { botOnline=false; addLog(`[Bot] Kicked: ${typeof r==='object'?JSON.stringify(r):r}`) })
  bot.on('error', (e) => { botOnline=false; addLog(`[Bot] Error: ${e.message}`) })
}

const PORT = process.env.PORT||3000
app.listen(PORT, () => { addLog(`[Server] Dashboard at http://localhost:${PORT}`); console.log(`✅ Open: http://localhost:${PORT}`); createBot() })
if (process.env.RENDER_EXTERNAL_URL) setInterval(()=>require('http').get(process.env.RENDER_EXTERNAL_URL,()=>{}).on('error',()=>{}),4*60*1000)
