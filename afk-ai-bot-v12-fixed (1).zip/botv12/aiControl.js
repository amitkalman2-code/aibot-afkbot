const { addLog } = require('./logger')

// ── AI AUTONOMOUS CONTROL ─────────────────────────────────────────────────────
// When enabled, the AI gets full control of the bot every tick interval.
// It sees the bot's state and decides what to do next — chat, walk, jump, etc.

let aiControlInterval = null
let aiControlActive = false
let currentGoal = null
let goalProgress = []
let aiControlThinkTime = 8000 // ms between AI decisions

const GOALS = {
  'get_wood':       { name:'🪵 Get Wood',         desc:'Collect 64 logs of any wood',       check:(bot)=>countItem(bot,'log')>=64 },
  'get_stone':      { name:'⛏ Get Stone',         desc:'Mine 32 cobblestone blocks',        check:(bot)=>countItem(bot,'cobblestone')>=32 },
  'get_iron':       { name:'🔩 Get Iron',          desc:'Smelt 16 iron ingots',              check:(bot)=>countItem(bot,'iron_ingot')>=16 },
  'get_diamond':    { name:'💎 Get Diamonds',      desc:'Mine 5 diamonds',                   check:(bot)=>countItem(bot,'diamond')>=5 },
  'get_food':       { name:'🍖 Get Food',          desc:'Have 32 food items in inventory',   check:(bot)=>countFood(bot)>=32 },
  'make_bed':       { name:'🛏 Make a Bed',        desc:'Craft and have a bed',              check:(bot)=>countItem(bot,'bed')>=1 },
  'kill_zombie':    { name:'🧟 Kill a Zombie',     desc:'Kill at least 1 zombie',            check:(bot,state)=>state.kills?.zombie>=1 },
  'kill_skeleton':  { name:'💀 Kill a Skeleton',   desc:'Kill at least 1 skeleton',          check:(bot,state)=>state.kills?.skeleton>=1 },
  'kill_creeper':   { name:'💥 Kill a Creeper',    desc:'Kill at least 1 creeper',           check:(bot,state)=>state.kills?.creeper>=1 },
  'kill_10_mobs':   { name:'⚔️ Kill 10 Mobs',     desc:'Kill any 10 hostile mobs',          check:(bot,state)=>(state.totalKills||0)>=10 },
  'reach_nether':   { name:'🔥 Enter Nether',      desc:'Travel to the Nether dimension',    check:(bot)=>bot.game?.dimension==='the_nether' },
  'reach_end':      { name:'🌌 Enter The End',     desc:'Travel to The End dimension',       check:(bot)=>bot.game?.dimension==='the_end' },
  'full_iron_armor':{ name:'🛡 Full Iron Armor',   desc:'Wear a full set of iron armor',     check:(bot)=>hasFullArmor(bot,'iron') },
  'full_diamond_armor':{ name:'🛡 Full Diamond Armor',desc:'Wear a full set of diamond armor',check:(bot)=>hasFullArmor(bot,'diamond') },
  'make_sword':     { name:'🗡 Craft a Sword',     desc:'Have any sword in inventory',       check:(bot)=>countItem(bot,'sword')>=1 },
  'make_pickaxe':   { name:'⛏ Craft a Pickaxe',   desc:'Have any pickaxe',                  check:(bot)=>countItem(bot,'pickaxe')>=1 },
  'reach_y30':      { name:'🕳 Reach Deep Cave',   desc:'Get to Y level 30 or below',        check:(bot)=>bot.entity?.position?.y<=30 },
  'reach_height':   { name:'☁️ Reach the Sky',    desc:'Get to Y level 200 or above',       check:(bot)=>bot.entity?.position?.y>=200 },
  'explore_500':    { name:'🗺 Explore 500 Blocks',desc:'Walk 500 blocks from spawn',        check:(bot,state)=>(state.maxDist||0)>=500 },
  'beat_game':      { name:'👑 Beat the Game',     desc:'Kill the Ender Dragon',             check:(bot,state)=>state.kills?.ender_dragon>=1 },
}

function countItem(bot, name) {
  try { return bot.inventory.items().filter(i=>i.name.includes(name)).reduce((s,i)=>s+i.count,0) } catch(_) { return 0 }
}
function countFood(bot) {
  const foods=['bread','apple','beef','chicken','pork','fish','carrot','potato','cookie','cake','pie','melon','mushroom_stew','rabbit_stew','soup']
  try { return bot.inventory.items().filter(i=>foods.some(f=>i.name.includes(f))).reduce((s,i)=>s+i.count,0) } catch(_) { return 0 }
}
function hasFullArmor(bot, material) {
  try {
    const slots=bot.inventory.slots
    const pieces=['helmet','chestplate','leggings','boots']
    return pieces.every(p=>pieces.find((_,i)=>{
      const slot=slots[5+pieces.indexOf(p)]
      return slot&&slot.name.includes(material)&&slot.name.includes(p)
    }))
  } catch(_) { return false }
}

let goalState = { kills:{}, totalKills:0, maxDist:0, spawnPos:null }

function getBotState(bot) {
  try {
    const pos = bot.entity?.position
    if (pos && goalState.spawnPos) {
      const dx=pos.x-goalState.spawnPos.x, dz=pos.z-goalState.spawnPos.z
      const dist=Math.sqrt(dx*dx+dz*dz)
      if (dist>goalState.maxDist) goalState.maxDist=dist
    }
    const items = bot.inventory.items().slice(0,8).map(i=>`${i.name}x${i.count}`).join(', ')
    return {
      pos: pos ? `${Math.round(pos.x)},${Math.round(pos.y)},${Math.round(pos.z)}` : 'unknown',
      health: bot.health||20,
      food: bot.food||20,
      dimension: bot.game?.dimension||'overworld',
      inventory: items||'empty',
      goal: currentGoal ? GOALS[currentGoal]?.name : 'none',
      goalProgress: goalProgress.slice(-3).join(' → '),
    }
  } catch(_) { return { pos:'unknown', health:20, food:20, dimension:'overworld', inventory:'empty', goal:'none', goalProgress:'' } }
}

async function aiControlTick(bot, aiConfig, doAction, askAI) {
  if (!bot || !bot.entity) return
  try {
    const state = getBotState(bot)
    const goalInfo = currentGoal && GOALS[currentGoal] ? `Current goal: ${GOALS[currentGoal].name} — ${GOALS[currentGoal].desc}` : 'No active goal. Explore and survive.'

    // Check goal completion
    if (currentGoal && GOALS[currentGoal]) {
      if (GOALS[currentGoal].check(bot, goalState)) {
        addLog(`[AI Control] ✅ Goal complete: ${GOALS[currentGoal].name}`)
        try { bot.chat(`Goal complete: ${GOALS[currentGoal].name}! 🎉`) } catch(_) {}
        goalProgress.push(`✅ ${GOALS[currentGoal].name}`)
        currentGoal = null
      }
    }

    const prompt = `You are controlling a Minecraft 1.21.1 bot autonomously.
Bot state: pos=${state.pos}, health=${state.health}/20, food=${state.food}/20, dimension=${state.dimension}
Inventory: ${state.inventory}
${goalInfo}
Recent progress: ${state.goalProgress||'none'}

Pick ONE action to do right now. Reply with ONLY the command, nothing else.
Available commands:
walk X Y Z | walk forward N | walk back N | mine <block> | find <block> | jump | eat | health | follow <player> | come | look around | say <message> | sprint on | sprint off | sneak | unsneak | inv | nearby | kill <mob> | stop | spin | patrol`

    const reply = (await askAI(prompt, aiConfig)).trim().replace(/^(command:|action:|do\s+)/i,'')
    addLog(`[AI Control] Decided: ${reply.slice(0,60)}`)
    await doAction(bot, reply, aiConfig, true)
  } catch(e) {
    addLog(`[AI Control] Error: ${e.message}`)
  }
}

function startAIControl(bot, aiConfig, doAction, askAI, intervalMs) {
  stopAIControl()
  aiControlActive = true
  goalState.spawnPos = bot.entity?.position ? { x:bot.entity.position.x, z:bot.entity.position.z } : null

  // Hook mob kills
  bot.on('entityDead', (entity) => {
    if (!entity) return
    const name = entity.name?.toLowerCase()
    if (!name) return
    const hostile=['zombie','skeleton','creeper','spider','witch','enderman','phantom','slime','blaze','ghast','pillager','ravager','vindicator','evoker','ender_dragon']
    if (hostile.includes(name)) {
      goalState.kills[name] = (goalState.kills[name]||0)+1
      goalState.totalKills++
      addLog(`[AI Control] Kill: ${name} (total: ${goalState.totalKills})`)
    }
  })

  addLog(`[AI Control] 🤖 Started — thinking every ${Math.round(intervalMs/1000)}s`)
  aiControlInterval = setInterval(()=>aiControlTick(bot,aiConfig,doAction,askAI), intervalMs)
}

function stopAIControl() {
  aiControlActive = false
  if (aiControlInterval) { clearInterval(aiControlInterval); aiControlInterval=null }
  addLog('[AI Control] Stopped.')
}

function setGoal(goalKey) {
  if (!GOALS[goalKey]) return `Unknown goal: ${goalKey}`
  currentGoal = goalKey
  goalProgress.push(`Started: ${GOALS[goalKey].name}`)
  addLog(`[AI Control] Goal set: ${GOALS[goalKey].name}`)
  return `Goal set: ${GOALS[goalKey].name} — ${GOALS[goalKey].desc}`
}

function getGoals() { return GOALS }
function isActive() { return aiControlActive }
function getCurrentGoal() { return currentGoal ? GOALS[currentGoal] : null }
function getGoalProgress() { return goalProgress }
function getGoalState() { return goalState }
function resetGoalState() { goalState = { kills:{}, totalKills:0, maxDist:0, spawnPos:null }; goalProgress=[]; currentGoal=null }

module.exports = { startAIControl, stopAIControl, setGoal, getGoals, isActive, getCurrentGoal, getGoalProgress, getGoalState, resetGoalState, GOALS }
