const fs = require('fs'), path = require('path')
const FILE = path.join(__dirname, 'config.json')
const DEFAULTS = {
  server: { host:'', port:25565, username:'AFKBot', version:'1.21.11', reconnectDelay:5000, autoReconnect:true },
  ai: {
    provider:'groq', chatPrefix:'ask', doPrefix:'do', respondToAll:false,
    personality:'You are a helpful Minecraft bot. Keep replies under 200 characters. Be friendly.',
    keys:{
      claude:'',chatgpt:'',groq:'',grok:'',gemini:'',mistral:'',cohere:'',deepseek:'',
      together:'',openrouter:'',perplexity:'',glm:'',moonshot:'',llama:'',qwen:'',yi:'',
      nvidia:'',cerebras:'',fireworks:'',sambanova:'',hyperbolic:'',
      aimlapi:'',chutes:'',featherless:'',novita:'',avian:'',deepinfra:'',lepton:'',
      kluster:'',scaleway:'',zukijourney:'',
    }
  },
  bot: {
    antiAfk:true, jumpInterval:60, stayMin:60, stayMax:300,
    neverLeave:true,
    chatLog:true, autoReconnect:true, reconnectDelay:5000,
    sneakOnAttack:false, sprintOnWalk:false, lookAtPlayers:false,
    randomLook:false, randomLookInterval:120,
    welcomeMsg:false, welcomeText:'Hello! I am an AFK bot.',
    playerJoinMsg:false, playerJoinText:'Welcome {player} to the server!',
    playerLeaveMsg:false, playerLeaveText:'Goodbye {player}!',
    privateMsg:true,
    guardMode:false, guardRange:5,
    collectDrops:false, chatResponse:true, muteChat:false,
    autoEat:false,
    followPlayer:'', followRange:3,
    pvpMode:false, fleeFromMobs:false, fleeRange:8,
    coordsOnSpawn:false,
    realisticKB:true,
    simpleVoiceChat:false,
    simpleVoiceChatTTS:false,
  },
  customCmds: {},
  mods: []
}
function loadSettings() {
  try {
    if (fs.existsSync(FILE)) {
      const s = JSON.parse(fs.readFileSync(FILE,'utf8'))
      return {
        server:{ ...DEFAULTS.server,...s.server },
        ai:{ ...DEFAULTS.ai,...s.ai, keys:{ ...DEFAULTS.ai.keys,...(s.ai?.keys||{}) } },
        bot:{ ...DEFAULTS.bot,...s.bot },
        customCmds:s.customCmds||{},
        mods:s.mods||[]
      }
    }
  } catch(e) { console.error('[Settings]',e.message) }
  return JSON.parse(JSON.stringify(DEFAULTS))
}
function saveSettings(data) {
  const cur = loadSettings()
  const merged = {
    server:{ ...cur.server,...(data.server||{}) },
    ai:{ ...cur.ai,...(data.ai||{}), keys:{ ...cur.ai.keys,...(data.ai?.keys||{}) } },
    bot:{ ...cur.bot,...(data.bot||{}) },
    customCmds:data.customCmds!==undefined?data.customCmds:cur.customCmds,
    mods:data.mods!==undefined?data.mods:cur.mods
  }
  fs.writeFileSync(FILE, JSON.stringify(merged,null,2))
}
module.exports = { loadSettings, saveSettings }
