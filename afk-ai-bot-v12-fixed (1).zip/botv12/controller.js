const { WebSocketServer } = require('ws')
const { addLog } = require('./logger')

let wss = null
let controlBot = null
let controlActive = false
let clients = new Set()
let frameInterval = null

// keys currently held down by the browser client
let held = { forward:false, back:false, left:false, right:false, jump:false, sneak:false, sprint:false }
let holdInterval = null

// prismarine-viewer renderer reference (set after viewer starts)
let viewerRef = null

function setViewer(v) {
  viewerRef = v
}

// Capture a JPEG frame from prismarine-viewer's WebGL canvas
async function captureFrame() {
  try {
    if (!viewerRef) return null

    // prismarine-viewer exposes its Three.js renderer
    // Try different paths depending on viewer version
    const renderer =
      viewerRef.viewer?.renderer ||
      viewerRef.renderer ||
      (viewerRef.three && viewerRef.three.renderer)

    if (!renderer) return null

    // Get the underlying GL context (headless-gl or canvas)
    const gl = renderer.getContext ? renderer.getContext() : null
    if (!gl) return null

    const width = renderer.domElement ? renderer.domElement.width : 854
    const height = renderer.domElement ? renderer.domElement.height : 480

    // Read pixels from WebGL framebuffer
    const pixels = new Uint8Array(width * height * 4)
    gl.readPixels(0, 0, width, height, gl.RGBA, gl.UNSIGNED_BYTE, pixels)

    // Flip vertically (WebGL origin is bottom-left)
    const flipped = new Uint8Array(width * height * 4)
    for (let y = 0; y < height; y++) {
      const src = (height - 1 - y) * width * 4
      const dst = y * width * 4
      flipped.set(pixels.subarray(src, src + width * 4), dst)
    }

    // Encode to JPEG using sharp (fast) or fall back to raw PNG via Canvas
    try {
      const sharp = require('sharp')
      const jpeg = await sharp(Buffer.from(flipped), {
        raw: { width, height, channels: 4 }
      }).jpeg({ quality: 75, mozjpeg: false }).toBuffer()
      return jpeg
    } catch(_) {
      // sharp not available — try canvas
      try {
        const { createCanvas } = require('canvas')
        const c = createCanvas(width, height)
        const ctx = c.getContext('2d')
        const imgData = ctx.createImageData(width, height)
        imgData.data.set(flipped)
        ctx.putImageData(imgData, 0, 0)
        return c.toBuffer('image/jpeg', { quality: 0.75 })
      } catch(_) {
        return null
      }
    }
  } catch(e) {
    return null
  }
}

function startController (bot, port) {
  controlBot = bot
  if (wss) { wss.close(); wss = null }

  wss = new WebSocketServer({ port })
  addLog(`[Controller] WebSocket on ws://localhost:${port}`)

  wss.on('connection', (ws) => {
    clients.add(ws)
    controlActive = true
    addLog('[Controller] Browser connected — manual control ON')
    ws.send(JSON.stringify({ type:'connected', msg:'Manual control active — WASD to move, mouse to look' }))

    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw)
        if (!controlBot) return

        if (msg.type === 'key') {
          if (msg.key in held) {
            held[msg.key] = msg.state
            try { controlBot.setControlState(msg.key, msg.state) } catch (_) {}
          }
        }

        if (msg.type === 'look') {
          try { controlBot.look(msg.yaw, msg.pitch, false) } catch (_) {}
        }

        if (msg.type === 'attack') {
          try {
            const entity = controlBot.nearestEntity(e => e && e !== controlBot.entity && controlBot.entity.position.distanceTo(e.position) < 5)
            if (entity) controlBot.attack(entity)
          } catch (_) {}
        }

        if (msg.type === 'use') {
          try { controlBot.activateItem() } catch (_) {}
        }

        if (msg.type === 'chat') {
          try { controlBot.chat(String(msg.text).slice(0, 256)) } catch (_) {}
        }

        if (msg.type === 'slot') {
          try { controlBot.setQuickBarSlot(Math.max(0, Math.min(8, msg.slot))) } catch (_) {}
        }

        if (msg.type === 'drop') {
          try { controlBot.tossStack(controlBot.inventory.slots[36 + (controlBot.quickBarSlot || 0)]) } catch (_) {}
        }

        if (msg.type === 'swapHands') {
          try {
            const heldSlot = 36 + (controlBot.quickBarSlot || 0)
            const heldItem = controlBot.inventory.slots[heldSlot]
            const offhand = controlBot.inventory.slots[45]
            if (heldItem) controlBot.moveSlotItem(heldSlot, 45).catch(() => {})
            else if (offhand) controlBot.moveSlotItem(45, heldSlot).catch(() => {})
          } catch (_) {}
        }

      } catch (e) {}
    })

    ws.on('close', () => {
      clients.delete(ws)
      if (clients.size === 0) {
        controlActive = false
        for (const k of Object.keys(held)) {
          held[k] = false
          try { controlBot && controlBot.setControlState(k, false) } catch (_) {}
        }
        addLog('[Controller] Browser disconnected — control released')
      }
    })
  })

  // Push bot state every 100ms
  holdInterval = setInterval(() => {
    if (!controlBot || !controlBot.entity || clients.size === 0) return
    try {
      const pos = controlBot.entity.position
      const inv = controlBot.inventory.slots.slice(36, 45).map(s => s ? { name: s.name, count: s.count } : null)
      const payload = JSON.stringify({
        type: 'state',
        health: Math.round(controlBot.health || 20),
        food: Math.round(controlBot.food || 20),
        pos: { x: Math.round(pos.x), y: Math.round(pos.y), z: Math.round(pos.z) },
        yaw: controlBot.entity.yaw,
        pitch: controlBot.entity.pitch,
        hotbar: inv,
        slot: controlBot.quickBarSlot || 0,
        dimension: controlBot.game?.dimension || 'overworld',
      })
      for (const ws of clients) { try { ws.send(payload) } catch (_) {} }
    } catch (_) {}
  }, 100)

  // Stream video frames at ~20fps over WebSocket
  // (60fps is too heavy for WS+JPEG — 20fps looks smooth and works reliably)
  const TARGET_FPS = 20
  frameInterval = setInterval(async () => {
    if (clients.size === 0) return
    const frame = await captureFrame()
    if (!frame) return
    // Send as binary with a 1-byte type prefix (0x01 = frame)
    const msg = Buffer.allocUnsafe(1 + frame.length)
    msg[0] = 0x01
    frame.copy(msg, 1)
    for (const ws of clients) {
      try { if (ws.readyState === 1) ws.send(msg) } catch (_) {}
    }
  }, Math.round(1000 / TARGET_FPS))
}

function stopController () {
  controlActive = false
  clearInterval(holdInterval)
  clearInterval(frameInterval)
  for (const k of Object.keys(held)) { held[k] = false; try { controlBot && controlBot.setControlState(k, false) } catch (_) {} }
  if (wss) { wss.close(); wss = null }
  clients.clear()
  addLog('[Controller] Stopped.')
}

function isControlActive () { return controlActive }

module.exports = { startController, stopController, isControlActive, setViewer }
