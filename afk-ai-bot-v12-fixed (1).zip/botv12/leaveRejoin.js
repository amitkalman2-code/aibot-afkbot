const { addLog } = require('./logger')
function randomMs(min,max){ return Math.floor(Math.random()*(max-min+1))+min }

function setupLeaveRejoin(bot, onDisconnect, getSettings) {
  let leaveTimer=null, jumpTimer=null, jumpOffTimer=null, stopped=false
  let stuckCheckTimer=null, lastPos=null, lastPosTime=0

  function cleanup(){
    stopped=true
    clearTimeout(leaveTimer); clearTimeout(jumpTimer); clearTimeout(jumpOffTimer)
    clearInterval(stuckCheckTimer)
    leaveTimer=jumpTimer=jumpOffTimer=stuckCheckTimer=null
  }

  function scheduleJump(){
    if(stopped||!bot.entity) return
    const cfg=getSettings()
    if(!cfg.bot.antiAfk) return
    try { bot.setControlState('jump',true) } catch(_) {}
    jumpOffTimer=setTimeout(()=>{ try{bot.setControlState('jump',false)}catch(_){} },300)
    jumpTimer=setTimeout(scheduleJump, randomMs((cfg.bot.jumpInterval||60)*1000, (cfg.bot.jumpInterval||60)*1500))
  }

  // auto-jump when stuck while pathfinding
  function startStuckCheck(){
    stuckCheckTimer=setInterval(()=>{
      if(stopped||!bot||!bot.entity) return
      let isMoving=false
      try{ isMoving=!!(bot.pathfinder&&bot.pathfinder.isMoving&&bot.pathfinder.isMoving()) }catch(_){}
      if(!isMoving){ lastPos=null; return }
      const pos=bot.entity.position
      const now=Date.now()
      if(lastPos){
        const dx=pos.x-lastPos.x, dz=pos.z-lastPos.z
        if(now-lastPosTime>1500 && Math.sqrt(dx*dx+dz*dz)<0.2){
          try{
            bot.setControlState('jump',true)
            setTimeout(()=>{try{bot.setControlState('jump',false)}catch(_){}},500)
          }catch(_){}
          lastPos={x:pos.x,y:pos.y,z:pos.z}; lastPosTime=now; return
        }
      }
      if(!lastPos||(Math.abs(pos.x-lastPos.x)+Math.abs(pos.z-lastPos.z))>0.3){
        lastPos={x:pos.x,y:pos.y,z:pos.z}; lastPosTime=now
      }
    },600)
  }

  bot.once('spawn',()=>{
    cleanup(); stopped=false; lastPos=null
    startStuckCheck()
    const cfg=getSettings()
    if(cfg.bot.neverLeave){
      addLog(`[AFK] Never-Leave ON — bot stays forever`)
      scheduleJump(); return
    }
    const stay=randomMs((cfg.bot.stayMin||60)*1000,(cfg.bot.stayMax||300)*1000)
    addLog(`[AFK] Cycling in ${Math.round(stay/1000)}s`)
    scheduleJump()
    leaveTimer=setTimeout(()=>{ if(stopped)return; cleanup(); try{bot.quit()}catch(_){} },stay)
  })

  bot.on('end',()=>{ cleanup(); onDisconnect() })
  bot.on('kicked',cleanup)
  bot.on('error',cleanup)
}

module.exports = setupLeaveRejoin
