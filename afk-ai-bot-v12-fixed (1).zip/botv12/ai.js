const { goals, Movements } = require('mineflayer-pathfinder')
const Vec3 = require('vec3')

// ── ALL PROVIDERS ─────────────────────────────────────────────────────────────
const PROVIDERS = {
  // existing
  claude:      'https://api.anthropic.com/v1/messages',
  chatgpt:     'https://api.openai.com/v1/chat/completions',
  groq:        'https://api.groq.com/openai/v1/chat/completions',
  grok:        'https://api.x.ai/v1/chat/completions',
  gemini:      'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
  mistral:     'https://api.mistral.ai/v1/chat/completions',
  cohere:      'https://api.cohere.ai/compatibility/v1/chat/completions',
  deepseek:    'https://api.deepseek.com/v1/chat/completions',
  together:    'https://api.together.xyz/v1/chat/completions',
  openrouter:  'https://openrouter.ai/api/v1/chat/completions',
  perplexity:  'https://api.perplexity.ai/chat/completions',
  glm:         'https://open.bigmodel.cn/api/paas/v4/chat/completions',
  moonshot:    'https://api.moonshot.cn/v1/chat/completions',
  llama:       'https://api.llama-api.com/chat/completions',
  qwen:        'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
  yi:          'https://api.01.ai/v1/chat/completions',
  nvidia:      'https://integrate.api.nvidia.com/v1/chat/completions',
  cerebras:    'https://api.cerebras.ai/v1/chat/completions',
  fireworks:   'https://api.fireworks.ai/inference/v1/chat/completions',
  sambanova:   'https://api.sambanova.ai/v1/chat/completions',
  hyperbolic:  'https://api.hyperbolic.xyz/v1/chat/completions',
  // 10 NEW free/cheap providers
  aimlapi:     'https://api.aimlapi.com/v1/chat/completions',
  chutes:      'https://llm.chutes.ai/v1/chat/completions',
  featherless: 'https://api.featherless.ai/v1/chat/completions',
  novita:      'https://api.novita.ai/v3/openai/chat/completions',
  avian:       'https://api.avian.io/v1/chat/completions',
  deepinfra:   'https://api.deepinfra.com/v1/openai/chat/completions',
  lepton:      'https://llama3-1-8b.lepton.run/api/v1/chat/completions',
  kluster:     'https://api.kluster.ai/v1/chat/completions',
  scaleway:    'https://api.scaleway.ai/v1/chat/completions',
  zukijourney: 'https://zukijourney.com/v1/chat/completions',
}

const MODELS = {
  claude:'claude-haiku-4-5', chatgpt:'gpt-4o-mini', groq:'llama-3.1-8b-instant',
  grok:'grok-3-mini', gemini:'gemini-2.0-flash', mistral:'mistral-small-latest',
  cohere:'command-r', deepseek:'deepseek-chat', together:'meta-llama/Llama-3-8b-chat-hf',
  openrouter:'meta-llama/llama-3.1-8b-instruct:free', perplexity:'llama-3.1-sonar-small-128k-online',
  glm:'glm-4-flash', moonshot:'moonshot-v1-8k', llama:'llama3.1-8b',
  qwen:'qwen-turbo', yi:'yi-lightning',
  nvidia:'meta/llama-3.1-8b-instruct', cerebras:'llama3.1-8b',
  fireworks:'accounts/fireworks/models/llama-v3p1-8b-instruct',
  sambanova:'Meta-Llama-3.1-8B-Instruct', hyperbolic:'meta-llama/Meta-Llama-3.1-8B-Instruct',
  // new
  aimlapi:'meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo',
  chutes:'deepseek-ai/DeepSeek-V3-0324',
  featherless:'meta-llama/Meta-Llama-3.1-8B-Instruct',
  novita:'meta-llama/llama-3.1-8b-instruct',
  avian:'gpt-4o-mini',
  deepinfra:'meta-llama/Meta-Llama-3.1-8B-Instruct',
  lepton:'llama3-1-8b',
  kluster:'klusterai/Meta-Llama-3.1-8B-Instruct-Turbo',
  scaleway:'llama-3.1-8b-instruct',
  zukijourney:'gpt-4o-mini',
}

let customCmds = {}
function setCustomCmds(c) { customCmds = c||{} }
function getCustomCmds() { return customCmds }
const repeatJobs = {}
function stopRepeat(id) { if(repeatJobs[id]){clearInterval(repeatJobs[id]);delete repeatJobs[id]} }
function stopAllRepeat() { Object.keys(repeatJobs).forEach(stopRepeat) }

// ── CORE AI CALL ──────────────────────────────────────────────────────────────
async function askAI(prompt, aiConfig, retries=2) {
  const provider = (aiConfig.provider||'groq').toLowerCase()
  const key = aiConfig.keys?.[provider]||''
  if (!key) throw new Error(`No API key for: ${provider}`)
  const url = PROVIDERS[provider]
  if (!url) throw new Error(`Unknown provider: ${provider}`)
  const sys = aiConfig.personality||'You are a helpful Minecraft bot. Keep replies under 200 characters. Be friendly.'

  for (let attempt=0; attempt<=retries; attempt++) {
    try {
      let r
      if (provider==='claude') {
        r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'},body:JSON.stringify({model:MODELS.claude,max_tokens:300,system:sys,messages:[{role:'user',content:prompt}]})})
        if(!r.ok) throw new Error(`Claude ${r.status}: ${await r.text()}`)
        return (await r.json()).content[0].text.trim()
      }
      r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`},body:JSON.stringify({model:MODELS[provider]||'llama3.1-8b',max_tokens:300,messages:[{role:'system',content:sys},{role:'user',content:prompt}]})})
      if(!r.ok) throw new Error(`${provider} ${r.status}: ${await r.text()}`)
      const txt = (await r.json()).choices[0].message.content.trim()
      if (!txt) throw new Error('Empty response')
      return txt
    } catch(e) {
      if (attempt>=retries) throw e
      await sleep(800*(attempt+1))
    }
  }
}

function sleep(ms){return new Promise(r=>setTimeout(r,ms))}
function getMode(bot){try{return bot.game?.gameMode||'survival'}catch(_){return 'survival'}}

// ── FIXED AI BUILD SYSTEM ────────────────────────────────────────────────────
async function aiBuild(bot, mcData, buildRequest, aiConfig) {
  const mode = getMode(bot)
  const inv = bot.inventory.items().map(i=>`${i.name}x${i.count}`).join(',') || 'empty'

  // Try up to 3 times if AI returns bad JSON
  for (let attempt=1; attempt<=3; attempt++) {
    const prompt = `You are a Minecraft building assistant. Build: "${buildRequest}"
Game mode: ${mode}
Inventory: ${inv}

RESPOND WITH VALID JSON ONLY. No markdown. No explanation. No code fences.
Schema:
{"name":"string","canBuild":true,"missingBlocks":[],"steps":[{"x":0,"y":0,"z":0,"block":"stone"}],"message":"string"}

Rules:
- steps = array of block placements, MAX 30 blocks
- x/y/z = relative integers from bot position (x=right, y=up, z=forward)
- block = exact Minecraft block name like oak_planks, cobblestone, glass, dirt
- If survival mode and missing items, set canBuild:false and list missingBlocks
- In creative mode, always set canBuild:true
- Keep structures small and simple (house = 5x4x5 box is fine)
- Only use very common blocks: stone, cobblestone, oak_planks, glass, dirt, sand, oak_log, oak_leaves, white_wool, gravel`

    let plan
    try {
      const raw = await askAI(prompt, aiConfig)
      // Strip any accidental markdown fences
      const cleaned = raw.replace(/```json\s*/gi,'').replace(/```\s*/g,'').trim()
      // Try to find JSON object even if there's extra text
      const match = cleaned.match(/\{[\s\S]*\}/)
      if (!match) throw new Error('No JSON object found in response')
      plan = JSON.parse(match[0])
    } catch(e) {
      if (attempt===3) return `AI couldn't plan the build after 3 tries: ${e.message}`
      await sleep(500)
      continue
    }

    if (!plan.canBuild) {
      return `Can't build ${plan.name||buildRequest} — missing: ${(plan.missingBlocks||[]).join(', ')}`
    }

    if (!plan.steps || !plan.steps.length) {
      if (attempt===3) return `AI returned no build steps for: ${buildRequest}`
      await sleep(500)
      continue
    }

    bot.chat(`Building ${plan.name||buildRequest} (${plan.steps.length} blocks)...`)
    const base = bot.entity.position.floored().offset(3,0,0)
    let placed = 0, failed = 0

    for (const step of plan.steps) {
      const worldPos = base.offset(step.x||0, step.y||0, step.z||0)
      const blockName = (step.block||'cobblestone').replace(/ /g,'_').toLowerCase()

      let item = bot.inventory.items().find(i=>i.name===blockName||i.name.includes(blockName.split('_')[0]))

      if (!item && mode==='creative') {
        try { bot.chat(`/give ${bot.username} ${blockName} 64`); await sleep(500) } catch(_) {}
        item = bot.inventory.items().find(i=>i.name===blockName||i.name.includes(blockName.split('_')[0]))
      }

      if (!item) { failed++; await sleep(50); continue }

      try {
        await bot.equip(item, 'hand')
        const faces = [[0,-1,0],[0,1,0],[1,0,0],[-1,0,0],[0,0,1],[0,0,-1]]
        let didPlace = false
        for (const [ox,oy,oz] of faces) {
          const ref = bot.blockAt(worldPos.offset(ox,oy,oz))
          if (ref && ref.name!=='air' && ref.name!=='cave_air' && ref.name!=='void_air') {
            try {
              await bot.placeBlock(ref, new Vec3(-ox,-oy,-oz))
              placed++
              didPlace = true
              break
            } catch(_) {}
          }
        }
        if (!didPlace) failed++
      } catch(_) { failed++ }
      await sleep(250)
    }

    return `${plan.message||`Built ${plan.name||buildRequest}`}! (${placed} placed, ${failed} skipped)`
  }
}

// ── MAIN DO ACTION ─────────────────────────────────────────────────────────────
async function doAction(bot, actionText, aiConfig, hasAPI) {
  const lower = actionText.toLowerCase().trim()
  const mcData = require('minecraft-data')(bot.version)

  // custom commands
  const cc = customCmds[lower]
  if (cc) {
    if (cc.type==='say') { bot.chat(cc.value); return `Said: ${cc.value}` }
    if (cc.type==='cmd') { bot.chat('/'+cc.value); return `Ran: /${cc.value}` }
    if (cc.type==='action') return await doAction(bot,cc.value,aiConfig,hasAPI)
    return `Custom: ${cc.value}`
  }

  // slash commands
  const slashM = lower.match(/^use\s+\/(.+)$/)
  if (slashM) { bot.chat('/'+slashM[1]); return `Ran: /${slashM[1]}` }

  // repeat
  const rpitM = lower.match(/^(.+?)\s+(?:rpit|repeat)\s+(\d+|until stop|forever)$/)
  if (rpitM) {
    const baseCmd=rpitM[1].trim(), timesStr=rpitM[2]
    const times=(timesStr==='until stop'||timesStr==='forever')?Infinity:parseInt(timesStr)
    const jobId='rpit_'+Date.now(); let count=0
    repeatJobs[jobId]=setInterval(async()=>{
      if(count>=times){stopRepeat(jobId);try{bot.chat(`Done repeating "${baseCmd}"`)}catch(_){};return}
      count++; try{await doAction(bot,baseCmd,aiConfig,hasAPI)}catch(_){}
    },2500)
    return times===Infinity?`Repeating "${baseCmd}" forever. Say "do stop repeat" to stop.`:`Repeating "${baseCmd}" ${times} times.`
  }
  if (lower==='stop repeat'||lower==='stop rpit'||lower==='stop repeating') { stopAllRepeat(); return 'Stopped all repeating.' }

  // ── HELP ──
  if (lower==='help') return 'Cmds: jump sneak sprint stop leave walk mine find kill follow come build inv health pos time say look msg give tp eat equip fly day night rain weather biome ping armor xp list mobs sleep use/ repeat stop-repeat spin circle dance wave patrol crouch-walk toss-junk look-around strafe charge roar sit'

  // ── MOVEMENT ──
  if (lower==='jump') { bot.setControlState('jump',true); setTimeout(()=>bot.setControlState('jump',false),500); return 'Jumped!' }
  if (lower==='sneak') { bot.setControlState('sneak',true); return 'Sneaking.' }
  if (lower==='unsneak'||lower==='stop sneak') { bot.setControlState('sneak',false); return 'Stopped sneaking.' }
  if (lower==='sprint') { bot.setControlState('sprint',true); return 'Sprinting!' }
  if (lower==='stop sprint') { bot.setControlState('sprint',false); return 'Stopped sprinting.' }

  const moveSecM = lower.match(/^(forward|back|left|right)\s+(\d+)$/)
  if (moveSecM) { const secs=Math.min(+moveSecM[2],60)*1000; bot.setControlState(moveSecM[1],true); setTimeout(()=>bot.setControlState(moveSecM[1],false),secs); return `Moving ${moveSecM[1]} ${moveSecM[2]}s.` }
  if (lower==='forward') { bot.setControlState('forward',true); setTimeout(()=>bot.setControlState('forward',false),2000); return 'Moving forward.' }
  if (lower==='back') { bot.setControlState('back',true); setTimeout(()=>bot.setControlState('back',false),2000); return 'Moving back.' }
  if (lower==='left') { bot.setControlState('left',true); setTimeout(()=>bot.setControlState('left',false),2000); return 'Moving left.' }
  if (lower==='right') { bot.setControlState('right',true); setTimeout(()=>bot.setControlState('right',false),2000); return 'Moving right.' }

  if (lower==='stop') { stopAllRepeat(); for(const s of ['forward','back','left','right','jump','sneak','sprint']) bot.setControlState(s,false); try{bot.pathfinder.stop()}catch(_){}; return 'Stopped.' }
  if (lower==='leave'||lower==='leave game'||lower==='disconnect') { bot.chat('Bye!'); setTimeout(()=>{try{bot.quit()}catch(_){}},1000); return 'Leaving...' }

  // ── NEW: SPIN ──
  if (lower==='spin') {
    let yaw=0; const iv=setInterval(()=>{ yaw+=0.4; try{bot.look(yaw,0,false)}catch(_){clearInterval(iv)} },80)
    setTimeout(()=>clearInterval(iv),3000); return 'Spinning!'
  }

  // ── NEW: CIRCLE (walk in a circle) ──
  if (lower==='circle') {
    let ang=0; const center=bot.entity.position.clone(); const iv=setInterval(()=>{
      ang+=0.15; const tx=center.x+Math.cos(ang)*4, tz=center.z+Math.sin(ang)*4
      try{bot.pathfinder.setGoal(new goals.GoalXZ(Math.round(tx),Math.round(tz)))}catch(_){clearInterval(iv)}
    },500)
    setTimeout(()=>{clearInterval(iv);try{bot.pathfinder.stop()}catch(_){}},8000)
    return 'Walking in a circle!'
  }

  // ── NEW: DANCE (jump + spin) ──
  if (lower==='dance') {
    let n=0, yaw=0; const iv=setInterval(()=>{
      n++; yaw+=0.8
      try{bot.look(yaw,0,false);bot.setControlState('jump',true);setTimeout(()=>bot.setControlState('jump',false),200)}catch(_){clearInterval(iv)}
      if(n>=15){clearInterval(iv);try{bot.setControlState('jump',false)}catch(_){}}
    },400)
    return 'Dancing!'
  }

  // ── NEW: WAVE (look up/down repeatedly) ──
  if (lower==='wave') {
    let n=0,up=true; const iv=setInterval(()=>{
      n++; try{bot.look(bot.entity.yaw,up?-0.8:0.3,true);up=!up}catch(_){clearInterval(iv)}
      if(n>=8)clearInterval(iv)
    },300)
    return 'Waving!'
  }

  // ── NEW: PATROL (walk back and forth) ──
  if (lower==='patrol') {
    const pos=bot.entity.position.clone(); let dir=1
    const iv=setInterval(()=>{
      const tx=Math.round(pos.x)+dir*6,tz=Math.round(pos.z)
      try{bot.pathfinder.setGoal(new goals.GoalBlock(tx,Math.round(pos.y),tz))}catch(_){clearInterval(iv)}
      dir*=-1
    },4000)
    repeatJobs['patrol_'+Date.now()]=iv
    return 'Patrolling! Say "do stop" to stop.'
  }

  // ── NEW: STRAFE (side to side) ──
  if (lower==='strafe') {
    let n=0
    const iv=setInterval(()=>{
      n++
      bot.setControlState('left',n%2===0); bot.setControlState('right',n%2===1)
      if(n>=8){clearInterval(iv);bot.setControlState('left',false);bot.setControlState('right',false)}
    },400)
    return 'Strafing!'
  }

  // ── NEW: CHARGE (run forward fast) ──
  if (lower==='charge') {
    bot.setControlState('sprint',true); bot.setControlState('forward',true)
    setTimeout(()=>{bot.setControlState('sprint',false);bot.setControlState('forward',false)},3000)
    return 'Charging forward!'
  }

  // ── NEW: ROAR (jump + say) ──
  if (lower==='roar') {
    bot.setControlState('jump',true); setTimeout(()=>bot.setControlState('jump',false),500)
    bot.chat('RAAAARGH!'); return 'RAAAARGH!'
  }

  // ── NEW: SIT (sneak + stop) ──
  if (lower==='sit') {
    try{bot.pathfinder.stop()}catch(_){}
    bot.setControlState('sneak',true)
    for(const s of ['forward','back','left','right','sprint']) bot.setControlState(s,false)
    return 'Sitting down (sneaking).'
  }

  // ── NEW: STAND ──
  if (lower==='stand') { bot.setControlState('sneak',false); return 'Standing up.' }

  // ── NEW: TOSS JUNK (drop everything except tools/armor) ──
  if (lower==='toss junk'||lower==='drop junk') {
    const keep=['sword','axe','pickaxe','shovel','hoe','helmet','chestplate','leggings','boots','bow','shield','arrow','totem']
    const items=bot.inventory.items().filter(i=>!keep.some(k=>i.name.includes(k)))
    if(!items.length) return 'No junk to drop.'
    for(const i of items){try{await bot.tossStack(i)}catch(_){}}
    return `Dropped ${items.length} junk items!`
  }

  // ── NEW: LOOK AROUND (scan all directions) ──
  if (lower==='look around'||lower==='scan') {
    const dirs=[[0,0],[Math.PI/2,0],[Math.PI,0],[Math.PI*1.5,0],[0,-0.5],[0,0.5]]
    let i=0; const iv=setInterval(()=>{
      if(i>=dirs.length){clearInterval(iv);return}
      try{bot.look(dirs[i][0],dirs[i][1],true)}catch(_){clearInterval(iv)}; i++
    },600)
    return 'Looking around...'
  }

  // ── NEW: SAY HELLO ──
  if (lower==='hello'||lower==='hi') { bot.chat('Hello! 👋'); return 'Said hello!' }

  // ── NEW: SHOW TIME ──
  if (lower==='irl time'||lower==='real time') { const n=new Date(); return `IRL time: ${n.toUTCString()}` }

  // ── NEW: HUNGER ──
  if (lower==='hunger'||lower==='food') { return `Food: ${Math.round(bot.food)}/20 (${bot.food<6?'Starving!':bot.food<10?'Hungry':'Full'})` }

  // ── NEW: SATURATION ──
  if (lower==='saturation'||lower==='sat') { return `Saturation: ${Math.round(bot.foodSaturation||0)}/20` }

  // ── NEW: NEARBY PLAYERS ──
  if (lower==='nearby'||lower==='near players') {
    const players=Object.values(bot.players||{}).filter(p=>p.username!==bot.username&&p.entity)
      .map(p=>{const d=bot.entity.position.distanceTo(p.entity.position);return `${p.username}(${Math.round(d)}m)`})
    return players.length?`Nearby: ${players.slice(0,6).join(', ')}`:'No players with visible entities.'
  }

  // ── NEW: SPEED CHECK ──
  if (lower==='speed') {
    try{const v=bot.entity.velocity;const sp=Math.sqrt(v.x*v.x+v.z*v.z).toFixed(2);return `Speed: ${sp} m/tick`}
    catch(_){return 'Speed: unknown'}
  }

  // ── NEW: FACING ──
  if (lower==='facing'||lower==='direction') {
    const yaw=bot.entity.yaw
    const dirs=['South','West','North','East']
    const i=Math.round(((yaw%(Math.PI*2))/(Math.PI*2))*4+2)%4
    return `Facing: ${dirs[i]} (yaw: ${Math.round(yaw*(180/Math.PI))}°)`
  }

  // ── NEW: VERSION ──
  if (lower==='version'||lower==='ver') { return `Minecraft ${bot.version} · AFK AI Bot v11` }

  // ── NEW: THROW (toss held item) ──
  if (lower==='throw'||lower==='toss') {
    const item=bot.inventory.slots[bot.quickBarSlot+36]
    if(!item) return 'Nothing in hand to throw.'
    try{await bot.tossStack(item);return `Threw ${item.name}!`}
    catch(e){return `Throw failed: ${e.message}`}
  }

  // ── NEW: HOTBAR SELECT ──
  const hotbarM=lower.match(/^slot\s+([1-9])$/)
  if(hotbarM){try{await bot.setQuickBarSlot(+hotbarM[1]-1);return `Selected slot ${hotbarM[1]}.`}catch(e){return `Slot error: ${e.message}`}}

  // ── LOOK ──
  const lookDirs={north:[Math.PI,0],south:[0,0],east:[-Math.PI/2,0],west:[Math.PI/2,0],up:[0,-Math.PI/2],down:[0,Math.PI/2]}
  const lookM=lower.match(/^look (north|south|east|west|up|down)$/)
  if (lookM){const[y,p]=lookDirs[lookM[1]];bot.look(y,p,true);return `Looking ${lookM[1]}.`}

  // ── WALK TO COORDS ──
  const walkM=lower.match(/^walk\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)$/)
  if (walkM) {
    const[x,y,z]=[+walkM[1],+walkM[2],+walkM[3]]
    try{
      const mv=new Movements(bot)
      mv.canDig=false
      mv.allowParkour=true
      mv.canJump=true
      mv.allowSprinting=true
      bot.pathfinder.setMovements(mv)
      // Use setGoal (non-blocking) — goto blocks and can timeout on long paths
      bot.pathfinder.setGoal(new goals.GoalBlock(x,y,z))
      return `Walking to ${x} ${y} ${z}... (will jump obstacles automatically)`
    }catch(e){return `Walk failed: ${e.message}`}
  }

  // ── FOLLOW ──
  const followM=lower.match(/^follow\s+(.+)$/)
  if (followM) {
    const name=followM[1].trim()
    if(name==='stop'||name==='nobody'){try{bot.pathfinder.stop()}catch(_){};return 'Stopped following.'}
    const entity=Object.values(bot.entities).find(e=>e.type==='player'&&(e.username||'').toLowerCase()===name.toLowerCase())
    if(!entity) return `Can't find player: ${name}`
    try{
      const mv=new Movements(bot);mv.canDig=false;mv.allowParkour=true;mv.canJump=true;mv.allowSprinting=true
      bot.pathfinder.setMovements(mv)
      bot.pathfinder.setGoal(new goals.GoalFollow(entity,3),true);return `Following ${name}!`}
    catch(e){return `Follow failed: ${e.message}`}
  }
  if (lower==='come'||lower==='come here') {
    const nearest=Object.values(bot.entities).find(e=>e.type==='player'&&e!==bot.entity)
    if(!nearest) return 'No players nearby.'
    try{bot.pathfinder.setGoal(new goals.GoalFollow(nearest,2),true);return 'Coming to you!'}
    catch(e){return `Can't come: ${e.message}`}
  }

  // ── MINE ──
  const mineM=lower.match(/^min(?:e)?\s+(.+)$/)
  if (mineM) {
    const name=mineM[1].trim().replace(/ /g,'_')
    let bt=mcData.blocksByName[name]||Object.values(mcData.blocksByName).find(b=>b.name.includes(name))
    if(!bt) return `Unknown block: ${name}`
    const block=bot.findBlock({matching:bt.id,maxDistance:48})
    if(!block) return `No ${name} within 48 blocks.`
    try{await bot.pathfinder.goto(new goals.GoalLookAtBlock(block.position,bot.world));await bot.dig(block);return `Mined ${bt.name}!`}
    catch(e){return `Mine failed: ${e.message}`}
  }

  // ── FIND BLOCK ──
  const findM=lower.match(/^find\s+(.+)$/)
  if (findM) {
    const name=findM[1].trim().replace(/ /g,'_')
    let bt=mcData.blocksByName[name]||Object.values(mcData.blocksByName).find(b=>b.name.includes(name))
    if(!bt) return `Unknown block: ${name}`
    const block=bot.findBlock({matching:bt.id,maxDistance:64})
    if(!block) return `No ${name} within 64 blocks.`
    const p=block.position;return `Found ${bt.name} at X:${p.x} Y:${p.y} Z:${p.z}`
  }

  // ── KILL ──
  const killM=lower.match(/^(?:kill|attack)\s+(.+)$/)
  if (killM) {
    const target=killM[1].trim()
    const entity=Object.values(bot.entities).find(e=>{if(!e||e===bot.entity)return false;return(e.name||'').toLowerCase().includes(target)||(e.username||'').toLowerCase()===target})
    if(!entity) return `Can't find ${target} nearby.`
    try{
      bot.pathfinder.setGoal(new goals.GoalFollow(entity,2),true)
      let atk=0
      const iv=setInterval(()=>{if(atk++>40||!entity.isValid){clearInterval(iv);try{bot.pathfinder.stop()}catch(_){};return};try{bot.attack(entity)}catch(_){clearInterval(iv)}},600)
      return `Attacking ${target}!`
    }catch(e){return `Attack failed: ${e.message}`}
  }
  if(lower==='stop attack'||lower==='stop kill'){try{bot.pathfinder.stop()}catch(_){};return 'Stopped attacking.'}

  // ── PLACE ──
  const placeM=lower.match(/^place\s+(.+)$/)
  if (placeM) {
    const name=placeM[1].trim().replace(/ /g,'_')
    const item=bot.inventory.items().find(i=>i.name.includes(name))
    if(!item) return `No ${name} in inventory.`
    const ref=bot.blockAt(bot.entity.position.offset(0,-1,0))
    if(!ref) return 'No surface to place on.'
    try{await bot.equip(item,'hand');await bot.placeBlock(ref,new Vec3(0,1,0));return `Placed ${name}!`}
    catch(e){return `Place failed: ${e.message}`}
  }

  // ── DROP ──
  const dropM=lower.match(/^drop\s+(.+)$/)
  if (dropM) {
    const name=dropM[1].trim().replace(/ /g,'_')
    const item=bot.inventory.items().find(i=>i.name.includes(name))
    if(!item) return `No ${name} in inventory.`
    await bot.tossStack(item);return `Dropped ${name}.`
  }
  if(lower==='toss all'||lower==='drop all'){const items=bot.inventory.items();if(!items.length)return 'Empty.';for(const i of items){try{await bot.tossStack(i)}catch(_){}};return 'Dropped everything!'}

  // ── BUILD — fixed AI build ──
  const buildM=lower.match(/^build\s+(.+)$/)
  if (buildM) {
    if (!hasAPI) return `Build needs AI API. Set an API key in AI Settings.`
    return await aiBuild(bot, mcData, buildM[1].trim(), aiConfig)
  }

  // ── INFO ──
  if(lower==='inv'||lower==='inventory'){const items=bot.inventory.items();if(!items.length)return 'Empty.';return 'Inv: '+items.slice(0,6).map(i=>`${i.name}x${i.count}`).join(', ')+(items.length>6?'...':'')}
  if(lower==='health'||lower==='hp') return `HP: ${Math.round(bot.health)}/20  Food: ${Math.round(bot.food)}/20`
  if(lower==='pos'||lower==='position'||lower==='where'){const p=bot.entity.position;return `X:${Math.round(p.x)} Y:${Math.round(p.y)} Z:${Math.round(p.z)}`}
  if(lower==='time'){const t=bot.time.timeOfDay;return `Time: ${t} (${t<6000?'Morning':t<12000?'Day':t<18000?'Evening':'Night'})`}
  if(lower==='gamemode'||lower==='mode') return `Mode: ${getMode(bot)}`
  if(lower==='ping'){try{return `Ping: ${bot.player?.ping||'?'}ms`}catch(_){return 'Ping: ?'}}
  if(lower==='weather'){try{return bot.isRaining?'It is raining.':'Weather is clear.'}catch(_){return 'Unknown.'}}
  if(lower==='xp'||lower==='level') return `XP: Level ${Math.floor(bot.experience?.level||0)} (${Math.floor((bot.experience?.progress||0)*100)}%)`
  if(lower==='armor'){const slots=[5,6,7,8].map(s=>{const i=bot.inventory.slots[s];return i?i.name:'none'});return `Armor: ${slots.join(', ')}`}
  if(lower==='list'||lower==='players'||lower==='who'){const p=Object.keys(bot.players||{}).filter(n=>n!==bot.username);return p.length?`Players: ${p.slice(0,8).join(', ')}`:'No other players online.'}
  if(lower==='entities'||lower==='mobs'){const e=Object.values(bot.entities).filter(e=>e!==bot.entity&&e.type!=='object').slice(0,8);return e.length?'Nearby: '+e.map(e=>e.name||e.username||'?').join(', '):'No entities nearby.'}
  if(lower==='biome'){try{return `Biome: ${bot.blockAt(bot.entity.position)?.biome?.name||'unknown'}`}catch(_){return 'Biome: unknown'}}

  // ── SAY ──
  const sayM=actionText.match(/^say\s+(.+)$/i)
  if(sayM){bot.chat(sayM[1]);return `Said: "${sayM[1]}"`}

  // ── PRIVATE MESSAGE ──
  const msgM=actionText.match(/^msg\s+(\S+)\s+(.+)$/i)
  if(msgM){bot.chat(`/msg ${msgM[1]} ${msgM[2]}`);return `Sent private msg to ${msgM[1]}.`}

  // ── GIVE ──
  const giveM=actionText.match(/^give\s+(\S+)\s+(\S+)(?:\s+(\d+))?$/i)
  if(giveM){bot.chat(`/give ${giveM[1]} ${giveM[2]} ${giveM[3]||1}`);return `Gave ${giveM[3]||1}x ${giveM[2]} to ${giveM[1]}.`}

  // ── TP ──
  const tpM=lower.match(/^tp\s+(.+)$/)
  if(tpM){bot.chat(`/tp ${tpM[1]}`);return `Teleporting to ${tpM[1]}.`}

  // ── GAME COMMANDS ──
  if(lower==='day'||lower==='set day'){bot.chat('/time set day');return 'Set time to day.'}
  if(lower==='night'||lower==='set night'){bot.chat('/time set night');return 'Set time to night.'}
  if(lower==='sun'||lower==='clear weather'){bot.chat('/weather clear');return 'Clear weather.'}
  if(lower==='rain'||lower==='set rain'){bot.chat('/weather rain');return 'Set rain.'}
  if(lower==='creative'||lower==='gmc'){bot.chat('/gamemode creative');return 'Creative mode.'}
  if(lower==='survival'||lower==='gms'){bot.chat('/gamemode survival');return 'Survival mode.'}
  if(lower==='spectator'||lower==='gmsp'){bot.chat('/gamemode spectator');return 'Spectator mode.'}
  if(lower==='adventure'||lower==='gma'){bot.chat('/gamemode adventure');return 'Adventure mode.'}
  if(lower==='fly'){bot.chat('/gamemode creative');return 'Creative mode — press space twice to fly.'}

  // ── EAT ──
  if(lower==='eat'){
    const food=bot.inventory.items().find(i=>{try{return mcData.itemsByName[i.name]?.food}catch(_){return false}})
    if(!food) return 'No food in inventory.'
    try{await bot.equip(food,'hand');await bot.consume();return `Ate ${food.name}!`}
    catch(e){return `Eat failed: ${e.message}`}
  }

  // ── EQUIP ──
  const equipM=lower.match(/^equip\s+(.+)$/)
  if(equipM){
    const name=equipM[1].trim().replace(/ /g,'_')
    const item=bot.inventory.items().find(i=>i.name.includes(name))
    if(!item) return `No ${name} in inventory.`
    try{await bot.equip(item,'hand');return `Equipped ${item.name}!`}
    catch(e){return `Equip failed: ${e.message}`}
  }

  // ── SLEEP ──
  if(lower==='sleep'){
    const bed=bot.findBlock({matching:b=>b.name.includes('bed'),maxDistance:32})
    if(!bed) return 'No bed nearby.'
    try{await bot.pathfinder.goto(new goals.GoalBlock(bed.position.x,bed.position.y,bed.position.z));await bot.sleep(bed);return 'Sleeping!'}
    catch(e){return `Sleep failed: ${e.message}`}
  }

  // ── RESPAWN ──
  if(lower==='respawn'){try{bot.chat('/kill');return 'Respawning...'}catch(_){return 'Could not respawn.'}}

  // ── KICK / BAN / OP ──
  const kickM=actionText.match(/^kick\s+(\S+)(?:\s+(.+))?$/i)
  if(kickM){bot.chat(`/kick ${kickM[1]} ${kickM[2]||'Kicked by bot'}`);return `Kicked ${kickM[1]}.`}
  const banM=actionText.match(/^ban\s+(\S+)(?:\s+(.+))?$/i)
  if(banM){bot.chat(`/ban ${banM[1]} ${banM[2]||'Banned by bot'}`);return `Banned ${banM[1]}.`}
  const opM=lower.match(/^op\s+(.+)$/)
  if(opM){bot.chat(`/op ${opM[1]}`);return `Opped ${opM[1]}.`}
  const deopM=lower.match(/^deop\s+(.+)$/)
  if(deopM){bot.chat(`/deop ${deopM[1]}`);return `Deopped ${deopM[1]}.`}
  const wlM=lower.match(/^whitelist\s+(add|remove)\s+(.+)$/)
  if(wlM){bot.chat(`/whitelist ${wlM[1]} ${wlM[2]}`);return `Whitelist ${wlM[1]} ${wlM[2]}.`}


  // ── SPRINT TOGGLE ──
  if(lower==='sprint on'||lower==='always sprint'){bot.setControlState('sprint',true);return 'Sprint ON.'}
  if(lower==='sprint off'){bot.setControlState('sprint',false);return 'Sprint OFF.'}

  // ── SNEAK TOGGLE ──
  if(lower==='sneak on'||lower==='always sneak'){bot.setControlState('sneak',true);return 'Sneak ON.'}
  if(lower==='sneak off'){bot.setControlState('sneak',false);return 'Sneak OFF.'}

  // ── WALK FORWARD / BACK / LEFT / RIGHT ──
  const walkDirM=lower.match(/^walk (forward|back|left|right)(?:\s+(\d+))?$/)
  if(walkDirM){
    const dir=walkDirM[1], dist=Math.min(+(walkDirM[2]||10),200)
    const pos=bot.entity.position
    const yaw=bot.entity.yaw
    const fwd={x:-Math.sin(yaw),z:-Math.cos(yaw)}
    const rgt={x:-Math.cos(yaw),z:Math.sin(yaw)}
    let tx=pos.x, tz=pos.z
    if(dir==='forward'){tx+=fwd.x*dist;tz+=fwd.z*dist}
    else if(dir==='back'){tx-=fwd.x*dist;tz-=fwd.z*dist}
    else if(dir==='left'){tx-=rgt.x*dist;tz-=rgt.z*dist}
    else if(dir==='right'){tx+=rgt.x*dist;tz+=rgt.z*dist}
    try{
      const mv=new Movements(bot)
      mv.canDig=false
      mv.allowParkour=true
      mv.canJump=true
      mv.allowSprinting=true
      bot.pathfinder.setMovements(mv)
      bot.pathfinder.setGoal(new goals.GoalBlock(Math.round(tx),Math.round(pos.y),Math.round(tz)))
      return `Walking ${dir} ~${dist} blocks...`
    }catch(e){return `Walk failed: ${e.message}`}
  }

  // ── STOP MOVING ──
  if(lower==='stop moving'||lower==='halt'){
    for(const s of ['forward','back','left','right','sprint','sneak','jump'])try{bot.setControlState(s,false)}catch(_){}
    try{bot.pathfinder.stop()}catch(_){}
    return 'Stopped all movement.'
  }

  // ── LOOK AT PLAYER ──
  const lookAtM=lower.match(/^look at\s+(.+)$/)
  if(lookAtM){
    const name=lookAtM[1].trim()
    const entity=Object.values(bot.entities).find(e=>e.type==='player'&&(e.username||'').toLowerCase()===name.toLowerCase())
    if(!entity) return `Can't find player: ${name}`
    try{bot.lookAt(entity.position.offset(0,1.6,0));return `Looking at ${name}.`}catch(e){return `Failed: ${e.message}`}
  }

  // ── NEAREST ENTITY ──
  if(lower==='nearest'||lower==='closest'){
    const ents=Object.values(bot.entities).filter(e=>e&&e!==bot.entity&&e.position)
      .sort((a,b)=>bot.entity.position.distanceTo(a.position)-bot.entity.position.distanceTo(b.position))
    if(!ents.length) return 'No entities nearby.'
    const e=ents[0],d=Math.round(bot.entity.position.distanceTo(e.position))
    return `Nearest: ${e.name||e.username||'?'} at ${d}m`
  }

  // ── JUMP COUNT ──
  const jumpNM=lower.match(/^jump\s+(\d+)$/)
  if(jumpNM){
    const n=Math.min(+jumpNM[1],20)
    let i=0
    const iv=setInterval(()=>{
      if(i++>=n){clearInterval(iv);return}
      bot.setControlState('jump',true)
      setTimeout(()=>{try{bot.setControlState('jump',false)}catch(_){}},250)
    },500)
    return `Jumping ${n} times!`
  }

  // ── SPIN FAST ──
  if(lower==='spin fast'||lower==='spinfast'){
    let a=0
    const iv=setInterval(()=>{a+=0.4;try{bot.look(a,0,false)}catch(_){clearInterval(iv)}},50)
    setTimeout(()=>clearInterval(iv),3000)
    return 'Spinning fast!'
  }

  // ── LIGHT LEVEL ──
  if(lower==='light'||lower==='light level'){
    try{const b=bot.blockAt(bot.entity.position);return `Light level: ${b?b.light:'unknown'}`}catch(_){return 'Light: unknown'}
  }

  // ── WORLD TYPE ──
  if(lower==='world'||lower==='dimension'){
    try{return `Dimension: ${bot.game?.dimension||'unknown'}`}catch(_){return 'Dimension: unknown'}
  }

  // ── BLOCK UNDER ──
  if(lower==='block under'||lower==='standing on'){
    try{const b=bot.blockAt(bot.entity.position.offset(0,-1,0));return `Standing on: ${b?b.name:'air'}`}catch(_){return 'unknown'}}

  // ── BLOCK LOOK ──
  if(lower==='block look'||lower==='looking at'){
    try{const b=bot.blockAtCursor(4);return b?`Looking at: ${b.name} @ ${b.position.toArray().join(',')}`:'Not looking at a block.'}catch(_){return 'unknown'}}

  // ── COUNT ITEM ──
  const countM=lower.match(/^count\s+(.+)$/)
  if(countM){
    const name=countM[1].trim().replace(/ /g,'_')
    const total=bot.inventory.items().filter(i=>i.name.includes(name)).reduce((s,i)=>s+i.count,0)
    return `${name}: ${total} in inventory`
  }

  // ── LIST ALL INVENTORY ──
  if(lower==='inv all'||lower==='inventory all'){
    const items=bot.inventory.items()
    if(!items.length) return 'Inventory empty.'
    return items.map(i=>`${i.name}x${i.count}`).join(', ')
  }

  // ── HOTBAR SHOW ──
  if(lower==='hotbar'){
    const slots=Array.from({length:9},(_,i)=>{const it=bot.inventory.slots[36+i];return it?`[${i+1}]${it.name}`:`[${i+1}]-`})
    return 'Hotbar: '+slots.join(' ')
  }

  // ── SERVER TPS (via /tps if on paper) ──
  if(lower==='tps'){bot.chat('/tps');return 'Checking TPS...'}

  // ── PLAYERS COUNT ──
  if(lower==='player count'||lower==='online count'){
    const n=Object.keys(bot.players||{}).length
    return `Players online: ${n}`
  }



  // ── AI FULL CONTROL ──────────────────────────────────────────────────────────
  const { startAIControl, stopAIControl, setGoal, getGoals, isActive, getCurrentGoal, getGoalProgress } = require('./aiControl')

  if (lower==='ai control on'||lower==='ai on'||lower==='start ai control') {
    if (!hasAPI) return 'Need an AI API key to use AI Control.'
    try { startAIControl(bot, aiConfig, doAction, askAI, 8000); return '🤖 AI Control ON — bot is now autonomous!' } catch(e) { return 'Failed: '+e.message }
  }
  if (lower==='ai control off'||lower==='ai off'||lower==='stop ai control') {
    try { stopAIControl(); return '🛑 AI Control OFF — bot is back to manual.' } catch(_) { return 'Stopped.' }
  }
  if (lower==='ai status'||lower==='ai control status') {
    const active=isActive(), goal=getCurrentGoal(), prog=getGoalProgress()
    return `AI Control: ${active?'🟢 ON':'🔴 OFF'} | Goal: ${goal?goal.name:'none'} | Progress: ${prog.slice(-2).join(' → ')||'none'}`
  }

  // ── GOALS ────────────────────────────────────────────────────────────────────
  if (lower==='goals'||lower==='list goals'||lower==='show goals') {
    const goals=getGoals()
    return Object.entries(goals).map(([k,g])=>`${g.name}: ${g.desc}`).join(' | ')
  }
  const goalM = lower.match(/^goal\s+(.+)$/)
  if (goalM) {
    const key = goalM[1].trim().replace(/ /g,'_')
    try { return setGoal(key) } catch(e) { return 'Goal not found. Say "do goals" to see all.' }
  }
  if (lower==='clear goal'||lower==='no goal') {
    try { const { resetGoalState } = require('./aiControl'); resetGoalState(); return 'Goal cleared.' } catch(_) { return 'Cleared.' }
  }
  if (lower==='goal progress'||lower==='progress') {
    const prog=getGoalProgress(); return prog.length?prog.join(' → '):'No progress yet.'
  }

  // ── UNKNOWN → AI if API set ──
  if (!hasAPI) return `Unknown command: "${actionText}". Set an API key for AI to interpret commands. Say "do help".`
  try {
    const aiPrompt=`You control a Minecraft bot. Player typed: "${actionText}"
Reply with ONLY one exact command from this list (no quotes, no explanation):
jump | sneak | unsneak | sprint | stop | leave | spin | dance | wave | roar | sit | stand | charge | patrol | strafe | circle | toss junk | look around | facing | version | hunger | speed | nearby | hello | walk X Y Z | mine <block> | find <block> | kill <mob> | follow <player> | come | say <message> | look north | look south | look east | look west | look up | look down | inv | health | pos | time | eat | fly | day | night | creative | survival | tp <player> | slot <1-9>
If none match: say I cannot do that`
    const reply=await askAI(aiPrompt,aiConfig)
    const cleaned=reply.trim().replace(/^(command:|cmd:)\s*/i,'')
    if(!cleaned.toLowerCase().startsWith('say i cannot')) return await doAction(bot,cleaned,aiConfig,hasAPI)
    return `I don't know how to "${actionText}". Say "do help" for all commands.`
  } catch(_){return `Unknown command. Say "do help".`}
}

module.exports = { askAI, doAction, PROVIDERS, MODELS, setCustomCmds, getCustomCmds, stopAllRepeat }
