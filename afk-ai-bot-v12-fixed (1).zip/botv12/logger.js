const logs = []
function addLog(msg) {
  const t = new Date().toLocaleTimeString()
  const line = `[${t}] ${msg}`
  console.log(line)
  logs.push(line)
  if (logs.length > 500) logs.shift()
}
function getLogs() { return logs }
module.exports = { addLog, getLogs }
