const mineflayer = require('mineflayer')
const { pathfinder, goals, Movements } = require('mineflayer-pathfinder')
const express = require('express')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { addLog, getLogs } = require('./logger')
const { askAI, doAction, setCustomCmds } = require('./ai')
const { loadSettings, saveSettings } = require('./settings')
const setupLeaveRejoin = require('./leaveRejoin')
const aiControl = require('./aiControl')
const controller = require('./controller')

const app = express()
app.use(express.json({ limit: '10mb' }))
app.use(express.static(path.join(__dirname, 'public')))

const modsDir = path.join(__dirname, 'mods')
if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir)
const skinsDir = path.join(__dirname, 'skins')
if (!fs.existsSync(skinsDir)) fs.mkdirSync(skinsDir)

const upload = multer({ dest: modsDir })
const skinUpload = multer({ dest: skinsDir, limits: { fileSize: 5*1024*1024 } })

let bot = null
let botOnline = false
let reconnectTimer = null
let randomLookTimer = null
let guardTimer = null
let collectTimer = null

function hasAPI() {
  const cfg = loadSettings()
  return !!(cfg.ai.keys?.[cfg.ai.provider] || '')
}

// ── API routes ────────────────────────────────────────────────────────────────
app.get('/controller', (req,res) => res.sendFile(require('path').join(__dirname,'public','controller.html')))

app.get('/api/settings', (req, res) => res.json(loadSettings()))
app.post('/api/settings', (req, res) => {
  saveSettings(req.body)
  if (req.body.customCmds) setCustomCmds(req.body.customCmds)
  addLog('[Settings] Saved.')
  applyBotSettings()
  res.json({ ok: true })
})
app.get('/api/status', (req, res) => res.json({ online: botOnline, logs: getLogs(), hasAPI: hasAPI() }))
app.post('/api/restart', (req, res) => {
  addLog('[Bot] Restart requested.')
  if (bot) { try { bot.quit() } catch(_) {} }
  clearTimeout(reconnectTimer)
  reconnectTimer = setTimeout(createBot, 2000)
  res.json({ ok: true })
})
app.post('/api/chat', (req, res) => {
  const { msg } = req.body
  if (!bot || !botOnline) return res.json({ ok: false, error: 'Bot offline' })
  try { bot.chat(String(msg)); addLog(`[Dashboard] Sent: ${msg}`); res.json({ ok: true }) }
  catch(e) { res.json({ ok: false, error: e.message }) }
})

// ── Skin upload ───────────────────────────────────────────────────────────────
app.post('/api/skin/upload', skinUpload.single('skin'), (req, res) => {
  if (!req.file) return res.json({ ok: false, error: 'No file' })
  const ext = path.extname(req.file.originalname).toLowerCase() || '.png'
  const dest = path.join(skinsDir, 'current' + ext)
  if (fs.existsSync(dest)) fs.unlinkSync(dest)
  fs.renameSync(req.file.path, dest)
  // Save skin path to config
  saveSettings({ bot: { skinFile: dest, skinExt: ext } })
  addLog(`[Skin] Uploaded: ${req.file.originalname}`)
  res.json({ ok: true, name: req.file.originalname, path: dest })
})
app.get('/api/skin/current', (req, res) => {
  const cfg = loadSettings()
  const f = cfg.bot?.skinFile
  if (f && fs.existsSync(f)) {
    res.setHeader('Content-Type', 'image/png')
    res.sendFile(f)
  } else {
    res.json({ ok: false, error: 'No skin set' })
  }
})
app.delete('/api/skin', (req, res) => {
  const cfg = loadSettings()
  const f = cfg.bot?.skinFile
  if (f && fs.existsSync(f)) fs.unlinkSync(f)
  saveSettings({ bot: { skinFile: '', skinExt: '' } })
  addLog('[Skin] Cleared')
  res.json({ ok: true })
})

// ── Voice endpoint (AI-powered NLU) ──────────────────────────────────────────
app.post('/api/voice', async (req, res) => {
  const { text } = req.body
  if (!text) return res.json({ ok: false, error: 'No text' })
  if (!bot || !botOnline) return res.json({ ok: false, error: 'Bot offline' })
  addLog(`[Voice] Heard: "${text}"`)
  const cfg = loadSettings()
  const api = hasAPI()
  let result = ''
  try {
    if (!api) {
      result = await doAction(bot, text, cfg.ai, false)
    } else {
      const voicePrompt = `You control a Minecraft bot. The player said via voice: "${text}"
Decide: DO something or ANSWER a question.
Reply ONLY with one of:
DO: <exact command>
ASK: <question>

Commands: jump | sneak | unsneak | sprint | stop | leave | spin | dance | wave | roar | sit | stand | charge | patrol | strafe | circle | toss junk | look around | facing | version | hunger | speed | nearby | hello | walk X Y Z | walk forward [N] | walk back [N] | walk left [N] | walk right [N] | mine <block> | find <block> | kill <mob> | follow <player> | come | say <message> | look north/south/east/west/up/down | look at <player> | inv | inv all | hotbar | health | pos | time | eat | fly | day | night | creative | survival | tp <player> | slot <1-9> | nearest | jump <N> | sprint on | sprint off | sneak on | sneak off | stop moving | block under | block look | count <item> | player count | tps | light level | dimension

Examples:
"go forward 20 blocks" → DO: walk forward 20
"walk to 0 100 0" → DO: walk 0 100 0
"follow Steve" → DO: follow Steve
"what is my health" → ASK: health
"say hello" → DO: say hello`

      const aiReply = (await askAI(voicePrompt, cfg.ai)).trim()
      addLog(`[Voice] AI: ${aiReply.slice(0,80)}`)
      if (aiReply.toUpperCase().startsWith('DO:')) {
        result = await doAction(bot, aiReply.slice(3).trim(), cfg.ai, api)
      } else if (aiReply.toUpperCase().startsWith('ASK:')) {
        const q = aiReply.slice(4).trim()
        result = await doAction(bot, q, cfg.ai, api)
        if (!result || result.startsWith('Unknown')) { result = await askAI(q, cfg.ai); try{bot.chat(result.slice(0,255))}catch(_){} }
      } else {
        result = await doAction(bot, aiReply, cfg.ai, api)
      }
    }
    addLog(`[Voice] Result: ${result.slice(0,80)}`)
    res.json({ ok: true, result })
  } catch(e) { addLog(`[Voice Error] ${e.message}`); res.json({ ok: false, error: e.message }) }
})

// ── Mods ──────────────────────────────────────────────────────────────────────
app.post('/api/mods/upload', upload.single('mod'), (req, res) => {
  if (!req.file) return res.json({ ok: false, error: 'No file' })
  const orig = req.file.originalname
  const dest = path.join(modsDir, orig)
  fs.renameSync(req.file.path, dest)
  const cfg = loadSettings()
  const mods = cfg.mods||[]
  if (!mods.find(m=>m.name===orig)) mods.push({ name:orig, note:'Uploaded', file:dest })
  saveSettings({ mods })
  addLog(`[Mods] Uploaded: ${orig}`)
  res.json({ ok: true, name: orig })
})
app.get('/api/mods', (req, res) => res.json(loadSettings().mods||[]))
app.delete('/api/mods/:name', (req, res) => {
  const name = decodeURIComponent(req.params.name)
  const cfg = loadSettings()
  saveSettings({ mods: (cfg.mods||[]).filter(m=>m.name!==name) })
  try { const f=path.join(modsDir,name); if(fs.existsSync(f)) fs.unlinkSync(f) } catch(_) {}
  addLog(`[Mods] Removed: ${name}`)
  res.json({ ok: true })
})

// ── AI Control API ───────────────────────────────────────────────────────────
app.post('/api/aicontrol/start', (req, res) => {
  if (!bot || !botOnline) return res.json({ ok:false, error:'Bot offline' })
  const cfg = loadSettings()
  const api = hasAPI()
  if (!api) return res.json({ ok:false, error:'No API key set' })
  const interval = (req.body.interval || 8) * 1000
  try {
    aiControl.startAIControl(bot, cfg.ai, doAction, askAI, interval)
    res.json({ ok:true })
  } catch(e) { res.json({ ok:false, error:e.message }) }
})
app.post('/api/aicontrol/stop', (req, res) => {
  try { aiControl.stopAIControl(); res.json({ ok:true }) } catch(e) { res.json({ ok:false, error:e.message }) }
})
app.post('/api/aicontrol/goal', (req, res) => {
  const { goal } = req.body
  if (!goal) return res.json({ ok:false, error:'No goal' })
  try { const msg=aiControl.setGoal(goal); res.json({ ok:true, msg }) } catch(e) { res.json({ ok:false, error:e.message }) }
})
app.post('/api/aicontrol/cleargoal', (req, res) => {
  try { aiControl.resetGoalState(); res.json({ ok:true }) } catch(e) { res.json({ ok:false, error:e.message }) }
})
app.get('/api/aicontrol/status', (req, res) => {
  const goal = aiControl.getCurrentGoal()
  const prog = aiControl.getGoalProgress()
  const state = aiControl.getGoalState()
  res.json({
    active: aiControl.isActive(),
    goal: goal || null,
    progress: prog,
    kills: state.kills,
    totalKills: state.totalKills,
    maxDist: Math.round(state.maxDist)
  })
})
app.get('/api/aicontrol/goals', (req, res) => {
  const goals = aiControl.getGoals()
  res.json(Object.entries(goals).map(([k,g])=>({ key:k, name:g.name, desc:g.desc })))
})

// ── Custom cmds ───────────────────────────────────────────────────────────────
app.get('/api/customcmds', (req, res) => res.json(loadSettings().customCmds || {}))
app.post('/api/customcmds', (req, res) => {
  saveSettings({ customCmds: req.body })
  setCustomCmds(req.body)
  addLog('[CustomCmds] Saved.')
  res.json({ ok: true })
})

// ── Apply bot settings live ───────────────────────────────────────────────────
function applyBotSettings() {
  if (!bot || !botOnline) return
  const cfg = loadSettings()
  const b = cfg.bot

  clearInterval(randomLookTimer)
  if (b.randomLook) {
    randomLookTimer = setInterval(() => {
      if (!bot||!botOnline) return
      try { bot.look(Math.random()*Math.PI*2,(Math.random()-.5)*Math.PI,false) } catch(_) {}
    }, (b.randomLookInterval||120)*1000)
  }

  clearInterval(guardTimer)
  if (b.guardMode) {
    const hostile=['zombie','skeleton','creeper','spider','witch','enderman','phantom','slime','blaze','ghast','pillager','ravager','vindicator','evoker']
    guardTimer = setInterval(() => {
      if (!bot||!botOnline) return
      const entity = Object.values(bot.entities).find(e=>{
        if(!e||e===bot.entity) return false
        return bot.entity.position.distanceTo(e.position)<=(b.guardRange||5) && hostile.includes((e.name||'').toLowerCase())
      })
      if (entity) { try{bot.pathfinder.setGoal(new goals.GoalFollow(entity,2),true);bot.attack(entity)}catch(_){} }
    }, 1000)
  }

  clearInterval(collectTimer)
  if (b.collectDrops) {
    collectTimer = setInterval(() => {
      if (!bot||!botOnline) return
      const drop = Object.values(bot.entities).find(e=>e.name==='item'&&bot.entity.position.distanceTo(e.position)<=8)
      if (drop) { try{bot.pathfinder.setGoal(new goals.GoalBlock(Math.round(drop.position.x),Math.round(drop.position.y),Math.round(drop.position.z)))}catch(_){} }
    }, 2000)
  }

  if (b.lookAtPlayers) {
    const nearest = Object.values(bot.entities).find(e=>e.type==='player'&&e!==bot.entity)
    if (nearest) try{bot.lookAt(nearest.position.offset(0,1.6,0))}catch(_){}
  }
  if (b.followPlayer) {
    const entity = Object.values(bot.entities).find(e=>e.type==='player'&&(e.username||'').toLowerCase()===b.followPlayer.toLowerCase())
    if (entity) {
      try{
        const mv=new Movements(bot); mv.canDig=false; mv.allowParkour=true; mv.canJump=true; mv.allowSprinting=true
        bot.pathfinder.setMovements(mv)
        bot.pathfinder.setGoal(new goals.GoalFollow(entity,b.followRange||3),true)
      }catch(_){}
    }
  }
}

// ── Realistic knockback ───────────────────────────────────────────────────────
function setupRealisticKB(bot) {
  bot._client.on('entity_velocity', (packet) => {
    try {
      if (!bot.entity) return
      if (!loadSettings().bot.realisticKB) return
      if (packet.entityId !== bot.entity.id) return
      bot.entity.velocity.x = packet.velocityX / 8000
      bot.entity.velocity.y = packet.velocityY / 8000
      bot.entity.velocity.z = packet.velocityZ / 8000
      try { bot.pathfinder.stop() } catch(_) {}
    } catch(_) {}
  })
}

// ── SimpleVoiceChat: listen for nearby speech via chat events ─────────────────
function setupSimpleVoiceChat(bot) {
  // SimpleVoiceChat mod sends voice transcriptions as chat packets with a prefix
  // Pattern: [SVC] <player>: <text>  OR  *player whispers* etc.
  // We hook raw chat and look for voice chat patterns
  bot._client.on('chat_message', async (packet) => {
    try {
      const cfg = loadSettings()
      if (!cfg.bot.simpleVoiceChat) return
      const raw = packet.unsignedContent || packet.message || ''
      const text = typeof raw === 'string' ? raw : JSON.stringify(raw)
      // Match SimpleVoiceChat transcription format
      const m = text.match(/\[SVC\]\s*([^:]+):\s*(.+)/i) || text.match(/\[Voice\]\s*([^:]+):\s*(.+)/i)
      if (!m) return
      const speaker = m[1].trim()
      const speech = m[2].trim()
      if ((speaker.toLowerCase() === bot.username.toLowerCase())) return
      addLog(`[SVC] <${speaker}> said: "${speech}"`)
      const api = hasAPI()
      if (!api) return
      // Use AI to understand and respond
      const prompt = `A player named ${speaker} said to you via voice chat in Minecraft: "${speech}"
Reply naturally in 1-2 short sentences as a friendly bot. Stay in character. Max 200 chars.`
      const reply = await askAI(prompt, cfg.ai)
      if (cfg.bot.simpleVoiceChatTTS) {
        // Send as text-to-speech via /tts command (if server has it) or regular chat
        try { bot.chat(`/tts ${reply.slice(0,200)}`) } catch(_) { try{bot.chat(reply.slice(0,200))}catch(_){} }
      } else {
        try { bot.chat(reply.slice(0,200)) } catch(_) {}
      }
    } catch(_) {}
  })
}

// ── Create bot ────────────────────────────────────────────────────────────────
function createBot() {
  const cfg = loadSettings()
  if (!cfg.server.host) { addLog('[Error] No server host. Configure in Server tab.'); return }
  addLog(`[Bot] Connecting to ${cfg.server.host}:${cfg.server.port} as "${cfg.server.username}"...`)
  setCustomCmds(cfg.customCmds||{})

  try {
    bot = mineflayer.createBot({
      host: cfg.server.host,
      port: cfg.server.port||25565,
      username: cfg.server.username||'AFKBot',
      version: cfg.server.version||'1.21.11',
      auth: 'offline',
      hideErrors: false,
      physicsEnabled: true,
    })
  } catch(e) { addLog(`[Bot] Failed: ${e.message}`); return }

  bot.loadPlugin(pathfinder)
  setupRealisticKB(bot)
  setupSimpleVoiceChat(bot)

  setupLeaveRejoin(bot, () => {
    const c = loadSettings()
    if (c.bot.autoReconnect!==false) { clearTimeout(reconnectTimer); reconnectTimer=setTimeout(createBot,c.bot.reconnectDelay||5000) }
  }, loadSettings)

  bot.once('spawn', () => {
    botOnline = true
    addLog(`[Bot] ✅ Joined ${cfg.server.host}`)
    const c = loadSettings()
    // Set up pathfinder movements with jumping enabled globally
    try {
      const mv = new Movements(bot)
      mv.canDig = false
      mv.allowParkour = true
      mv.canJump = true
      mv.allowSprinting = true
      bot.pathfinder.setMovements(mv)
    } catch(_) {}

    // Start prismarine-viewer (3D world view on port 3002) and pass ref to controller for frame streaming
    try {
      const { mineflayer: viewerPlugin } = require('prismarine-viewer')
      const viewerInstance = viewerPlugin(bot, { port: 3002, firstPerson: true })
      if (viewerInstance && controller.setViewer) controller.setViewer(viewerInstance)
      addLog('[Controller] 3D viewer started → http://localhost:3002')
    } catch(e) { addLog('[Controller] Viewer unavailable: ' + e.message) }

    // Start WebSocket controller on port 3001
    try {
      controller.startController(bot, 3001)
    } catch(e) { addLog('[Controller] WS error: ' + e.message) }
    if (c.bot.welcomeMsg && c.bot.welcomeText) setTimeout(()=>{ try{bot.chat(c.bot.welcomeText)}catch(_){} },1500)
    if (c.bot.coordsOnSpawn) { const p=bot.entity.position; setTimeout(()=>{ try{bot.chat(`Spawned at X:${Math.round(p.x)} Y:${Math.round(p.y)} Z:${Math.round(p.z)}`)}catch(_){} },2000) }
    applyBotSettings()
  })

  bot.on('playerJoined', (player) => {
    if (player.username===bot.username) return
    const c = loadSettings()
    addLog(`[Join] ${player.username} joined`)
    if (c.bot.playerJoinMsg && c.bot.playerJoinText) {
      setTimeout(()=>{ try{bot.chat(c.bot.playerJoinText.replace('{player}',player.username))}catch(_){} },1000)
    }
  })
  bot.on('playerLeft', (player) => {
    if (player.username===bot.username) return
    const c = loadSettings()
    addLog(`[Leave] ${player.username} left`)
    if (c.bot.playerLeaveMsg && c.bot.playerLeaveText) {
      setTimeout(()=>{ try{bot.chat(c.bot.playerLeaveText.replace('{player}',player.username))}catch(_){} },500)
    }
  })

  bot.on('chat', async (username, message) => {
    if (username===bot.username) return
    const c = loadSettings()
    if (c.bot.chatLog!==false && !c.bot.muteChat) addLog(`[Chat] <${username}> ${message}`)
    if (!c.bot.chatResponse||c.bot.muteChat) return
    const askPfx = (c.ai.chatPrefix||'ask').toLowerCase()
    const doPfx  = (c.ai.doPrefix||'do').toLowerCase()
    const msgL = message.toLowerCase()
    const api = hasAPI()
    if (msgL.includes('whispers')||msgL.startsWith('[pm]')||msgL.startsWith('(pm)')) {
      const content = message.replace(/.*?:\s*/,'').trim()
      if (content.toLowerCase().startsWith(doPfx+' ')) {
        try { const r=await doAction(bot,content.slice(doPfx.length+1).trim(),c.ai,api); bot.chat(`/msg ${username} ${r.slice(0,200)}`) } catch(_) {}
      } else if (content.toLowerCase().startsWith(askPfx+' ')) {
        try { const r=await askAI(content.slice(askPfx.length+1).trim(),c.ai); bot.chat(`/msg ${username} ${r.slice(0,200)}`) } catch(_) {}
      }
      return
    }
    if (msgL.startsWith(askPfx+' ')) {
      if (!api) { bot.chat('No AI API key set.'); return }
      try { const r=await askAI(message.slice(askPfx.length+1).trim(),c.ai); bot.chat(r.slice(0,255)) } catch(e) { bot.chat('AI error: '+e.message.slice(0,60)) }
      return
    }
    if (msgL.startsWith(doPfx+' ')) {
      try { const r=await doAction(bot,message.slice(doPfx.length+1).trim(),c.ai,api); bot.chat(r.slice(0,255)) } catch(e) { bot.chat('Error: '+e.message.slice(0,60)) }
      return
    }
    if (c.ai.respondToAll && api) {
      try { const r=await askAI(message,c.ai); bot.chat(r.slice(0,255)) } catch(_) {}
    }
  })

  bot.on('end', (reason) => {
    botOnline=false
    aiControl.stopAIControl()
    controller.stopController()
    clearInterval(randomLookTimer); clearInterval(guardTimer); clearInterval(collectTimer)
    addLog(`[Bot] Disconnected: ${reason}`)
    const c=loadSettings()
    if (c.bot.autoReconnect!==false) { clearTimeout(reconnectTimer); reconnectTimer=setTimeout(createBot,c.bot.reconnectDelay||5000) }
  })
  bot.on('kicked', (r) => { botOnline=false; addLog(`[Bot] Kicked: ${typeof r==='object'?JSON.stringify(r):r}`) })
  bot.on('error', (e) => { botOnline=false; addLog(`[Bot] Error: ${e.message}`) })
}

const PORT = process.env.PORT||3000
app.listen(PORT, () => { addLog(`[Server] Dashboard v11 → http://localhost:${PORT}`); console.log(`✅ Open: http://localhost:${PORT}`); createBot() })
if (process.env.RENDER_EXTERNAL_URL) setInterval(()=>require('http').get(process.env.RENDER_EXTERNAL_URL,()=>{}).on('error',()=>{}),4*60*1000)
