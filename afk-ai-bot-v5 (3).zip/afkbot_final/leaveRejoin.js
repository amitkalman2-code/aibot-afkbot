const { addLog } = require('./logger')
function randomMs(min,max){ return Math.floor(Math.random()*(max-min+1))+min }
function setupLeaveRejoin(bot, onDisconnect, getSettings) {
  let leaveTimer=null, jumpTimer=null, jumpOffTimer=null, stopped=false
  function cleanup(){
    stopped=true
    clearTimeout(leaveTimer); clearTimeout(jumpTimer); clearTimeout(jumpOffTimer)
    leaveTimer=jumpTimer=jumpOffTimer=null
  }
  function scheduleJump(){
    if(stopped||!bot.entity) return
    const cfg=getSettings()
    if(!cfg.bot.antiAfk) return
    bot.setControlState('jump',true)
    jumpOffTimer=setTimeout(()=>bot.setControlState('jump',false),300)
    jumpTimer=setTimeout(scheduleJump, randomMs((cfg.bot.jumpInterval||60)*1000, (cfg.bot.jumpInterval||60)*1000*2))
  }
  bot.once('spawn',()=>{
    cleanup(); stopped=false
    const cfg=getSettings()
    const stay=randomMs((cfg.bot.stayMin||60)*1000,(cfg.bot.stayMax||300)*1000)
    addLog(`[AFK] Will cycle in ${Math.round(stay/1000)}s`)
    scheduleJump()
    leaveTimer=setTimeout(()=>{
      if(stopped) return
      cleanup()
      try{ bot.quit() }catch(_){}
    },stay)
  })
  bot.on('end',()=>{ cleanup(); onDisconnect() })
  bot.on('kicked',cleanup)
  bot.on('error',cleanup)
}
module.exports = setupLeaveRejoin
