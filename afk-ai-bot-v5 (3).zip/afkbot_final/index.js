const mineflayer = require('mineflayer')
const { pathfinder, goals, Movements } = require('mineflayer-pathfinder')
const express = require('express')
const multer = require('multer')
const path = require('path')
const fs = require('fs')
const { addLog, getLogs } = require('./logger')
const { askAI, doAction, setCustomCmds, getCustomCmds, stopAllRepeat } = require('./ai')
const { loadSettings, saveSettings } = require('./settings')
const setupLeaveRejoin = require('./leaveRejoin')

const app = express()
app.use(express.json())
app.use(express.static(path.join(__dirname, 'public')))

const modsDir = path.join(__dirname, 'mods')
if (!fs.existsSync(modsDir)) fs.mkdirSync(modsDir)
const upload = multer({ dest: modsDir })

let bot = null
let botOnline = false
let reconnectTimer = null
let randomLookTimer = null
let guardTimer = null
let collectTimer = null

function hasAPI() {
  const cfg = loadSettings()
  const key = cfg.ai.keys?.[cfg.ai.provider] || ''
  return !!key
}

// ── API ────────────────────────────────────────────────────────────────────────
app.get('/api/settings', (req, res) => res.json(loadSettings()))
app.post('/api/settings', (req, res) => {
  saveSettings(req.body)
  if (req.body.customCmds) setCustomCmds(req.body.customCmds)
  addLog('[Settings] Saved.')
  applyBotSettings()
  res.json({ ok: true })
})
app.get('/api/status', (req, res) => res.json({ online: botOnline, logs: getLogs(), hasAPI: hasAPI() }))
app.post('/api/restart', (req, res) => {
  addLog('[Bot] Restart requested.')
  if (bot) { try { bot.quit() } catch(_) {} }
  clearTimeout(reconnectTimer)
  reconnectTimer = setTimeout(createBot, 2000)
  res.json({ ok: true })
})
app.post('/api/chat', (req, res) => {
  const { msg } = req.body
  if (!bot || !botOnline) return res.json({ ok:false, error:'Bot offline' })
  try { bot.chat(String(msg)); addLog(`[Dashboard] Sent: ${msg}`); res.json({ ok:true }) }
  catch(e) { res.json({ ok:false, error:e.message }) }
})

// custom commands API
app.get('/api/customcmds', (req, res) => res.json(loadSettings().customCmds || {}))
app.post('/api/customcmds', (req, res) => {
  const cmds = req.body
  saveSettings({ customCmds: cmds })
  setCustomCmds(cmds)
  addLog('[CustomCmds] Saved.')
  res.json({ ok: true })
})

// mods
app.post('/api/mods/upload', upload.single('mod'), (req, res) => {
  if (!req.file) return res.json({ ok:false, error:'No file' })
  const orig = req.file.originalname
  const dest = path.join(modsDir, orig)
  fs.renameSync(req.file.path, dest)
  const cfg = loadSettings()
  const mods = cfg.mods||[]
  if (!mods.find(m=>m.name===orig)) mods.push({ name:orig, note:'Uploaded', file:dest })
  saveSettings({ mods })
  addLog(`[Mods] Uploaded: ${orig}`)
  res.json({ ok:true, name:orig })
})
app.get('/api/mods', (req, res) => res.json(loadSettings().mods||[]))
app.delete('/api/mods/:name', (req, res) => {
  const name = decodeURIComponent(req.params.name)
  const cfg = loadSettings()
  saveSettings({ mods:(cfg.mods||[]).filter(m=>m.name!==name) })
  try { const f=path.join(modsDir,name); if(fs.existsSync(f)) fs.unlinkSync(f) } catch(_) {}
  addLog(`[Mods] Removed: ${name}`)
  res.json({ ok:true })
})

// ── Apply live settings ────────────────────────────────────────────────────────
function applyBotSettings() {
  if (!bot || !botOnline) return
  const cfg = loadSettings()
  const b = cfg.bot

  clearInterval(randomLookTimer)
  if (b.randomLook) {
    randomLookTimer = setInterval(() => {
      if (!bot||!botOnline) return
      try { bot.look(Math.random()*Math.PI*2, (Math.random()-.5)*Math.PI, false) } catch(_) {}
    }, (b.randomLookInterval||120)*1000)
  }

  clearInterval(guardTimer)
  if (b.guardMode) {
    const hostile = ['zombie','skeleton','creeper','spider','witch','enderman','phantom','slime','blaze','ghast','pillager','ravager','vindicator','evoker']
    guardTimer = setInterval(() => {
      if (!bot||!botOnline) return
      const entity = Object.values(bot.entities).find(e => {
        if (!e||e===bot.entity) return false
        return bot.entity.position.distanceTo(e.position)<=(b.guardRange||5) && hostile.includes((e.name||'').toLowerCase())
      })
      if (entity) { try { bot.pathfinder.setGoal(new goals.GoalFollow(entity,2),true); bot.attack(entity) } catch(_) {} }
    }, 1000)
  }

  clearInterval(collectTimer)
  if (b.collectDrops) {
    collectTimer = setInterval(() => {
      if (!bot||!botOnline) return
      const drop = Object.values(bot.entities).find(e=>e.name==='item'&&bot.entity.position.distanceTo(e.position)<=8)
      if (drop) { try { bot.pathfinder.setGoal(new goals.GoalBlock(Math.round(drop.position.x),Math.round(drop.position.y),Math.round(drop.position.z))) } catch(_) {} }
    }, 2000)
  }
}

// ── Create bot ─────────────────────────────────────────────────────────────────
function createBot() {
  const cfg = loadSettings()
  if (!cfg.server.host) { addLog('[Error] No server host. Configure in Server tab.'); return }
  addLog(`[Bot] Connecting to ${cfg.server.host}:${cfg.server.port} as "${cfg.server.username}"...`)

  // load custom commands
  setCustomCmds(cfg.customCmds || {})

  try {
    bot = mineflayer.createBot({
      host: cfg.server.host,
      port: cfg.server.port || 25565,
      username: cfg.server.username || 'AFKBot',
      version: cfg.server.version || '1.21.1',
      auth: 'offline',
      hideErrors: false,
    })
  } catch(e) { addLog(`[Bot] Failed: ${e.message}`); return }

  bot.loadPlugin(pathfinder)

  setupLeaveRejoin(bot, () => {
    const c = loadSettings()
    if (c.bot.autoReconnect !== false) {
      clearTimeout(reconnectTimer)
      reconnectTimer = setTimeout(createBot, c.bot.reconnectDelay||5000)
    }
  }, loadSettings)

  bot.once('spawn', () => {
    botOnline = true
    addLog(`[Bot] ✅ Joined ${cfg.server.host}`)
    const c = loadSettings()
    if (c.bot.welcomeMsg && c.bot.welcomeText) {
      setTimeout(()=>{ try{bot.chat(c.bot.welcomeText)}catch(_){} }, 1500)
    }
    // set pathfinder movements
    try {
      const movements = new Movements(bot)
      bot.pathfinder.setMovements(movements)
    } catch(_) {}
    applyBotSettings()
  })

  bot.on('chat', async (username, message) => {
    if (username === bot.username) return
    const c = loadSettings()
    if (c.bot.chatLog !== false && !c.bot.muteChat) addLog(`[Chat] <${username}> ${message}`)
    if (!c.bot.chatResponse || c.bot.muteChat) return

    const askPfx = (c.ai.chatPrefix||'ask').toLowerCase()
    const doPfx  = (c.ai.doPrefix||'do').toLowerCase()
    const msgL = message.toLowerCase()
    const apiAvailable = hasAPI()

    if (msgL.startsWith(askPfx + ' ')) {
      const q = message.slice(askPfx.length+1).trim()
      if (!apiAvailable) { bot.chat('No AI API key set. Go to dashboard AI Settings.'); return }
      addLog(`[AI] ask from ${username}: ${q}`)
      try {
        const reply = await askAI(q, c.ai)
        bot.chat(reply.slice(0,255))
        addLog(`[AI] Reply: ${reply.slice(0,80)}`)
      } catch(e) {
        bot.chat('AI error: '+e.message.slice(0,80))
        addLog(`[AI Error] ${e.message}`)
      }
      return
    }

    if (msgL.startsWith(doPfx + ' ')) {
      const cmd = message.slice(doPfx.length+1).trim()
      addLog(`[Do] ${username}: ${cmd}`)
      try {
        const result = await doAction(bot, cmd, c.ai, apiAvailable)
        bot.chat(result.slice(0,255))
        addLog(`[Do] ${result.slice(0,80)}`)
      } catch(e) {
        bot.chat('Error: '+e.message.slice(0,80))
        addLog(`[Do Error] ${e.message}`)
      }
      return
    }

    if (c.ai.respondToAll && apiAvailable) {
      try { const r=await askAI(message,c.ai); bot.chat(r.slice(0,255)) } catch(_) {}
    }
  })

  bot.on('end', (reason) => {
    botOnline = false
    clearInterval(randomLookTimer); clearInterval(guardTimer); clearInterval(collectTimer)
    addLog(`[Bot] Disconnected: ${reason}`)
    const c = loadSettings()
    if (c.bot.autoReconnect !== false) {
      clearTimeout(reconnectTimer)
      reconnectTimer = setTimeout(createBot, c.bot.reconnectDelay||5000)
    }
  })
  bot.on('kicked', (r) => { botOnline=false; addLog(`[Bot] Kicked: ${typeof r==='object'?JSON.stringify(r):r}`) })
  bot.on('error', (e) => { botOnline=false; addLog(`[Bot] Error: ${e.message}`) })
}

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
  addLog(`[Server] Dashboard at http://localhost:${PORT}`)
  console.log(`✅ Open: http://localhost:${PORT}`)
  createBot()
})
if (process.env.RENDER_EXTERNAL_URL) {
  setInterval(()=>require('http').get(process.env.RENDER_EXTERNAL_URL,()=>{}).on('error',()=>{}), 4*60*1000)
}
