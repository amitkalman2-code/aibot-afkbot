const { goals, Movements } = require('mineflayer-pathfinder')
const Vec3 = require('vec3')

const PROVIDERS = {
  claude:     'https://api.anthropic.com/v1/messages',
  chatgpt:    'https://api.openai.com/v1/chat/completions',
  groq:       'https://api.groq.com/openai/v1/chat/completions',
  grok:       'https://api.x.ai/v1/chat/completions',
  gemini:     'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
  mistral:    'https://api.mistral.ai/v1/chat/completions',
  cohere:     'https://api.cohere.ai/compatibility/v1/chat/completions',
  deepseek:   'https://api.deepseek.com/v1/chat/completions',
  together:   'https://api.together.xyz/v1/chat/completions',
  openrouter: 'https://openrouter.ai/api/v1/chat/completions',
  perplexity: 'https://api.perplexity.ai/chat/completions',
  glm:        'https://open.bigmodel.cn/api/paas/v4/chat/completions',
  moonshot:   'https://api.moonshot.cn/v1/chat/completions',
  llama:      'https://api.llama-api.com/chat/completions',
  qwen:       'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
  yi:         'https://api.01.ai/v1/chat/completions',
}
const MODELS = {
  claude:'claude-haiku-4-5', chatgpt:'gpt-4o-mini', groq:'llama-3.1-8b-instant',
  grok:'grok-3-mini', gemini:'gemini-2.0-flash', mistral:'mistral-small-latest',
  cohere:'command-r', deepseek:'deepseek-chat', together:'meta-llama/Llama-3-8b-chat-hf',
  openrouter:'openai/gpt-4o-mini', perplexity:'llama-3.1-sonar-small-128k-online',
  glm:'glm-4-flash', moonshot:'moonshot-v1-8k', llama:'llama3.1-8b', qwen:'qwen-turbo', yi:'yi-lightning'
}

// ── repeat state ──────────────────────────────────────────────────────────────
const repeatJobs = {}
function stopRepeat(id) { if (repeatJobs[id]) { clearInterval(repeatJobs[id]); delete repeatJobs[id] } }
function stopAllRepeat() { Object.keys(repeatJobs).forEach(stopRepeat) }

// ── custom commands store ─────────────────────────────────────────────────────
let customCmds = {}
function setCustomCmds(c) { customCmds = c || {} }
function getCustomCmds() { return customCmds }

// ── AI call ───────────────────────────────────────────────────────────────────
async function askAI(prompt, aiConfig) {
  const provider = (aiConfig.provider || 'groq').toLowerCase()
  const key = aiConfig.keys?.[provider] || ''
  if (!key) throw new Error(`No API key for: ${provider}`)
  const url = PROVIDERS[provider]
  if (!url) throw new Error(`Unknown provider: ${provider}`)
  const sys = aiConfig.personality || 'You are a helpful Minecraft bot. Keep replies under 200 characters. Be friendly.'
  if (provider === 'claude') {
    const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json','x-api-key':key,'anthropic-version':'2023-06-01'}, body:JSON.stringify({model:MODELS.claude,max_tokens:200,system:sys,messages:[{role:'user',content:prompt}]}) })
    if (!r.ok) throw new Error(`Claude ${r.status}: ${await r.text()}`)
    return (await r.json()).content[0].text.trim()
  }
  const r = await fetch(url, { method:'POST', headers:{'Content-Type':'application/json','Authorization':`Bearer ${key}`}, body:JSON.stringify({model:MODELS[provider]||'gpt-4o-mini',max_tokens:200,messages:[{role:'system',content:sys},{role:'user',content:prompt}]}) })
  if (!r.ok) throw new Error(`${provider} ${r.status}: ${await r.text()}`)
  return (await r.json()).choices[0].message.content.trim()
}

// ── Build system ──────────────────────────────────────────────────────────────
const BUILD_BLUEPRINTS = {
  'tnt cannon': async (bot, mcData, mode) => {
    const blocks = { tnt:1, obsidian:12, water_bucket:1, stone:20 }
    return await tryBuild(bot, mcData, mode, 'TNT Cannon', blocks, async (pos) => {
      // simple tnt cannon layout
      const placements = [
        [0,0,0,'obsidian'],[1,0,0,'obsidian'],[2,0,0,'obsidian'],[3,0,0,'obsidian'],
        [0,1,0,'obsidian'],[0,1,1,'obsidian'],[0,1,2,'obsidian'],
        [1,1,0,'tnt'],[2,1,0,'tnt'],[3,1,0,'tnt']
      ]
      for (const [x,y,z,name] of placements) {
        await placeBlockAt(bot, mcData, pos.offset(x,y,z), name)
        await sleep(200)
      }
    })
  },
  'house': async (bot, mcData, mode) => {
    const blocks = { oak_planks:64, oak_log:16, glass:8 }
    return await tryBuild(bot, mcData, mode, 'House', blocks, async (pos) => {
      // 5x5 floor, 3 high walls, door gap
      for (let x=0;x<5;x++) for (let z=0;z<5;z++) await placeBlockAt(bot, mcData, pos.offset(x,-1,z), 'oak_planks')
      for (let y=0;y<3;y++) {
        for (let x=0;x<5;x++) { await placeBlockAt(bot, mcData, pos.offset(x,y,0),'oak_log'); await placeBlockAt(bot, mcData, pos.offset(x,y,4),'oak_log') }
        for (let z=1;z<4;z++) { await placeBlockAt(bot, mcData, pos.offset(0,y,z),'oak_log'); await placeBlockAt(bot, mcData, pos.offset(4,y,z),'oak_log') }
      }
    })
  },
  'tower': async (bot, mcData, mode, args) => {
    const h = parseInt(args[0]) || 10
    const blocks = { cobblestone: h*4 }
    return await tryBuild(bot, mcData, mode, `Tower (${h} high)`, blocks, async (pos) => {
      for (let y=0;y<h;y++) {
        await placeBlockAt(bot, mcData, pos.offset(0,y,0),'cobblestone')
        await placeBlockAt(bot, mcData, pos.offset(1,y,0),'cobblestone')
        await placeBlockAt(bot, mcData, pos.offset(0,y,1),'cobblestone')
        await placeBlockAt(bot, mcData, pos.offset(1,y,1),'cobblestone')
        await sleep(100)
      }
    })
  },
  'wall': async (bot, mcData, mode, args) => {
    const w = parseInt(args[0]) || 5, h = parseInt(args[1]) || 3
    const blocks = { cobblestone: w*h }
    return await tryBuild(bot, mcData, mode, `Wall ${w}x${h}`, blocks, async (pos) => {
      for (let x=0;x<w;x++) for (let y=0;y<h;y++) {
        await placeBlockAt(bot, mcData, pos.offset(x,y,0),'cobblestone'); await sleep(80)
      }
    })
  },
  'floor': async (bot, mcData, mode, args) => {
    const w = parseInt(args[0]) || 5, d = parseInt(args[1]) || 5
    const blocks = { oak_planks: w*d }
    return await tryBuild(bot, mcData, mode, `Floor ${w}x${d}`, blocks, async (pos) => {
      for (let x=0;x<w;x++) for (let z=0;z<d;z++) {
        await placeBlockAt(bot, mcData, pos.offset(x,-1,z),'oak_planks'); await sleep(80)
      }
    })
  },
}

async function tryBuild(bot, mcData, mode, name, neededBlocks, buildFn) {
  if (mode !== 'creative') {
    // check inventory
    const missing = []
    for (const [block, count] of Object.entries(neededBlocks)) {
      const have = bot.inventory.items().filter(i=>i.name.includes(block)).reduce((a,i)=>a+i.count,0)
      if (have < count) missing.push(`${block} x${count-have}`)
    }
    if (missing.length) return `Missing blocks to build ${name}: ${missing.join(', ')}`
  }
  const pos = bot.entity.position.floored().offset(2,0,0)
  try { await buildFn(pos); return `Built ${name}!` }
  catch(e) { return `Build failed: ${e.message}` }
}

async function placeBlockAt(bot, mcData, pos, blockName) {
  try {
    const item = bot.inventory.items().find(i=>i.name.includes(blockName))
    if (item) await bot.equip(item, 'hand')
    const ref = bot.blockAt(pos.offset(0,-1,0))
    if (ref) await bot.placeBlock(ref, new Vec3(0,1,0))
  } catch(_) {}
}

function sleep(ms) { return new Promise(r=>setTimeout(r,ms)) }

function getGameMode(bot) {
  try { return bot.game?.gameMode || 'survival' } catch(_) { return 'survival' }
}

// ── Main do action ─────────────────────────────────────────────────────────────
async function doAction(bot, actionText, aiConfig, hasAPI) {
  const lower = actionText.toLowerCase().trim()
  const mcData = require('minecraft-data')(bot.version)

  // ── custom commands ──
  const cc = customCmds[lower] || customCmds[actionText]
  if (cc) {
    if (cc.type === 'say') { bot.chat(cc.value); return `Said: ${cc.value}` }
    if (cc.type === 'cmd') { bot.chat('/' + cc.value); return `Ran: /${cc.value}` }
    if (cc.type === 'action') return await doAction(bot, cc.value, aiConfig, hasAPI)
    return `Custom cmd: ${cc.value}`
  }

  // ── /give and slash commands ──
  const slashM = lower.match(/^use\s+\/(.+)$/)
  if (slashM) {
    const cmd = slashM[1]
    bot.chat('/' + cmd)
    return `Ran: /${cmd}`
  }

  // ── repeat ──
  const rpitM = lower.match(/^(.+?)\s+rpit\s+(\d+|until stop)$/)
  if (rpitM) {
    const baseCmd = rpitM[1].trim()
    const times = rpitM[2] === 'until stop' ? Infinity : parseInt(rpitM[2])
    const jobId = 'rpit_' + Date.now()
    let count = 0
    repeatJobs[jobId] = setInterval(async () => {
      if (count >= times) { stopRepeat(jobId); bot.chat(`Done repeating "${baseCmd}"`); return }
      count++
      try { await doAction(bot, baseCmd, aiConfig, hasAPI) } catch(_) {}
    }, 2500)
    return times === Infinity ? `Repeating "${baseCmd}" until "do stop repeat"` : `Repeating "${baseCmd}" ${times}x`
  }
  if (lower === 'stop repeat' || lower === 'stop rpit') { stopAllRepeat(); return 'Stopped all repeating.' }

  // ── help ──
  if (lower === 'help') return 'ask <q> | do jump|sneak|sprint|stop|leave|walk X Y Z|mine <b>|find <b>|kill <n>|place <b>|drop <i>|build <type>|inv|health|pos|time|say <msg>|look <dir>|use /<cmd>|<cmd> rpit <n>'

  // ── movement ──
  if (lower === 'jump') { bot.setControlState('jump',true); setTimeout(()=>bot.setControlState('jump',false),500); return 'Jumped!' }
  if (lower === 'sneak') { bot.setControlState('sneak',true); return 'Sneaking.' }
  if (lower === 'unsneak'||lower==='stop sneak') { bot.setControlState('sneak',false); return 'Stopped sneaking.' }
  if (lower === 'sprint') { bot.setControlState('sprint',true); return 'Sprinting!' }
  if (lower === 'stop sprint') { bot.setControlState('sprint',false); return 'Stopped sprinting.' }
  if (lower === 'forward') { bot.setControlState('forward',true); setTimeout(()=>bot.setControlState('forward',false),2000); return 'Moving forward.' }
  if (lower === 'back') { bot.setControlState('back',true); setTimeout(()=>bot.setControlState('back',false),2000); return 'Moving back.' }
  if (lower === 'left') { bot.setControlState('left',true); setTimeout(()=>bot.setControlState('left',false),2000); return 'Moving left.' }
  if (lower === 'right') { bot.setControlState('right',true); setTimeout(()=>bot.setControlState('right',false),2000); return 'Moving right.' }
  if (lower === 'stop') {
    stopAllRepeat()
    for (const s of ['forward','back','left','right','jump','sneak','sprint']) bot.setControlState(s,false)
    try { bot.pathfinder.stop() } catch(_) {}
    return 'Stopped everything.'
  }
  if (lower === 'leave'||lower==='leave game') { bot.chat('Bye!'); setTimeout(()=>{ try{bot.quit()}catch(_){} },1000); return 'Leaving...' }

  // ── look ──
  const lookDirs = { north:[Math.PI,0],south:[0,0],east:[-Math.PI/2,0],west:[Math.PI/2,0],up:[0,-Math.PI/2],down:[0,Math.PI/2] }
  const lookM = lower.match(/^look (north|south|east|west|up|down)$/)
  if (lookM) { const [y,p]=lookDirs[lookM[1]]; bot.look(y,p,true); return `Looking ${lookM[1]}.` }

  // ── walk to coords ──
  const walkM = lower.match(/^walk\s+(-?\d+)\s+(-?\d+)\s+(-?\d+)$/)
  if (walkM) {
    const [x,y,z]=[+walkM[1],+walkM[2],+walkM[3]]
    try {
      const movements = new Movements(bot)
      movements.canDig = false
      bot.pathfinder.setMovements(movements)
      bot.pathfinder.setGoal(new goals.GoalBlock(x,y,z))
      return `Walking to ${x} ${y} ${z}...`
    } catch(e) { return `Pathfinder error: ${e.message}` }
  }

  // ── mine ──
  const mineM = lower.match(/^min(?:e)?\s+(.+)$/)
  if (mineM) {
    const name = mineM[1].trim().replace(/ /g,'_')
    let bt = mcData.blocksByName[name] || Object.values(mcData.blocksByName).find(b=>b.name.includes(name))
    if (!bt) return `Unknown block: ${name}`
    const block = bot.findBlock({ matching:bt.id, maxDistance:48 })
    if (!block) return `No ${name} within 48 blocks.`
    try {
      await bot.pathfinder.goto(new goals.GoalLookAtBlock(block.position, bot.world))
      await bot.dig(block)
      return `Mined ${bt.name}!`
    } catch(e) { return `Mine failed: ${e.message}` }
  }

  // ── find ──
  const findM = lower.match(/^find\s+(.+)$/)
  if (findM) {
    const name = findM[1].trim().replace(/ /g,'_')
    let bt = mcData.blocksByName[name] || Object.values(mcData.blocksByName).find(b=>b.name.includes(name))
    if (!bt) return `Unknown block: ${name}`
    const block = bot.findBlock({ matching:bt.id, maxDistance:64 })
    if (!block) return `No ${name} within 64 blocks.`
    const p = block.position; return `Found ${bt.name} at X:${p.x} Y:${p.y} Z:${p.z}`
  }

  // ── kill ──
  const killM = lower.match(/^kill\s+(.+)$/)
  if (killM) {
    const target = killM[1].trim()
    const entity = Object.values(bot.entities).find(e=>{
      if (!e||e===bot.entity) return false
      return (e.name||'').toLowerCase().includes(target)||(e.username||'').toLowerCase()===target
    })
    if (!entity) return `Can't find ${target} nearby.`
    try {
      bot.pathfinder.setGoal(new goals.GoalFollow(entity,2),true)
      let atk=0
      const iv=setInterval(()=>{
        if(atk++>40||!entity.isValid){clearInterval(iv);try{bot.pathfinder.stop()}catch(_){} return}
        try{bot.attack(entity)}catch(_){clearInterval(iv)}
      },600)
      return `Attacking ${target}!`
    } catch(e) { return `Attack failed: ${e.message}` }
  }

  // ── place ──
  const placeM = lower.match(/^place\s+(.+)$/)
  if (placeM) {
    const name = placeM[1].trim().replace(/ /g,'_')
    const item = bot.inventory.items().find(i=>i.name.includes(name))
    if (!item) return `No ${name} in inventory.`
    const ref = bot.blockAt(bot.entity.position.offset(0,-1,0))
    if (!ref) return 'No surface to place on.'
    try { await bot.equip(item,'hand'); await bot.placeBlock(ref,new Vec3(0,1,0)); return `Placed ${name}!` }
    catch(e) { return `Place failed: ${e.message}` }
  }

  // ── drop ──
  const dropM = lower.match(/^drop\s+(.+)$/)
  if (dropM) {
    const name = dropM[1].trim().replace(/ /g,'_')
    const item = bot.inventory.items().find(i=>i.name.includes(name))
    if (!item) return `No ${name} in inventory.`
    await bot.tossStack(item); return `Dropped ${name}.`
  }

  // ── build <type> [args] ──
  const buildM = lower.match(/^build\s+(.+)$/)
  if (buildM) {
    const parts = buildM[1].trim().split(/\s+/)
    const mode = getGameMode(bot)
    // try exact match first
    const key = Object.keys(BUILD_BLUEPRINTS).find(k => buildM[1].trim().startsWith(k))
    if (key) {
      const args = buildM[1].trim().slice(key.length).trim().split(/\s+/)
      return await BUILD_BLUEPRINTS[key](bot, mcData, mode, args)
    }
    // ask AI what to build if no match and has API
    if (hasAPI) {
      return `I don't have a blueprint for "${buildM[1]}". Known builds: ${Object.keys(BUILD_BLUEPRINTS).join(', ')}`
    }
    return `Unknown build. Available: ${Object.keys(BUILD_BLUEPRINTS).join(', ')}`
  }

  // ── info ──
  if (lower==='inv'||lower==='inventory') {
    const items=bot.inventory.items()
    if (!items.length) return 'Inventory empty.'
    return 'Inv: '+items.slice(0,6).map(i=>`${i.name}x${i.count}`).join(', ')+(items.length>6?'...':'')
  }
  if (lower==='health'||lower==='hp') return `HP: ${Math.round(bot.health)}/20  Food: ${Math.round(bot.food)}/20`
  if (lower==='pos'||lower==='position'||lower==='where') { const p=bot.entity.position; return `X:${Math.round(p.x)} Y:${Math.round(p.y)} Z:${Math.round(p.z)}` }
  if (lower==='time') { const t=bot.time.timeOfDay; return `Time: ${t} (${t<6000?'Morning':t<12000?'Day':t<18000?'Evening':'Night'})` }
  if (lower==='gamemode'||lower==='mode') { return `Game mode: ${getGameMode(bot)}` }

  // ── say ──
  const sayM = actionText.match(/^say\s+(.+)$/i)
  if (sayM) { bot.chat(sayM[1]); return `Said: "${sayM[1]}"` }

  // ── if no API just say unknown ──
  if (!hasAPI) return `Unknown command: "${actionText}". API not configured. Say "do help".`

  // ── AI interprets unknown command ──
  // AI should return ONLY a simple do command or say text, not ramble
  try {
    const aiPrompt = `You are controlling a Minecraft bot. The player said: "${actionText}"
Map this to ONE of these exact commands (respond with ONLY the command, nothing else):
jump, sneak, unsneak, sprint, stop, leave, walk X Y Z, mine <block>, find <block>, kill <name>, place <block>, drop <item>, look north/south/east/west/up/down, say <message>, inv, health, pos, time
If it's movement to a place you can't pathfind, respond: say I cannot reach there, I am stuck
If completely unclear, respond: say I don't understand that command`
    const reply = await askAI(aiPrompt, aiConfig)
    const cleaned = reply.trim().replace(/^(command:|cmd:|action:)\s*/i,'')
    // if AI returned a known command, execute it
    if (!cleaned.toLowerCase().startsWith('say ') && cleaned.split(' ').length <= 6) {
      return await doAction(bot, cleaned, aiConfig, hasAPI)
    }
    // otherwise just say it
    const msg = cleaned.replace(/^say\s+/i,'').slice(0,255)
    bot.chat(msg)
    return `Said: ${msg}`
  } catch(e) {
    return `Unknown command. Say "do help" for list.`
  }
}

module.exports = { askAI, doAction, PROVIDERS, MODELS, setCustomCmds, getCustomCmds, stopAllRepeat }
